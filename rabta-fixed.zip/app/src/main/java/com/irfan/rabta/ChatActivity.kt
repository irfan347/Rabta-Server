package com.irfan.rabta

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.media.AudioManager
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.text.Editable
import android.text.InputType
import android.text.TextWatcher
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import java.security.SecureRandom
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class ChatActivity : Activity(), RabtaEvents.Listener {

    companion object { @Volatile var openPeer: String? = null }

    private val GREEN   = 0xFF128C7E.toInt()
    private val GREEN2  = 0xFF25D366.toInt()
    private val BEIGE   = 0xFFECE5DD.toInt()
    private val SENT    = 0xFFDCF8C6.toInt()
    private val RECV    = Color.WHITE
    private val TXT     = 0xFF111B21.toInt()
    private val SUB     = 0xFF667781.toInt()
    private val DARK    = 0xFF0C1317.toInt()
    private val DARK2   = 0xFF1F2C34.toInt()
    private val GRAY_BTN= 0xFF2A3942.toInt()
    private val RED     = 0xFFD32F2F.toInt()

    private lateinit var peerId: String
    private lateinit var peerName: String
    private var isGroup = false
    private lateinit var chatBox: LinearLayout
    private lateinit var chatScroll: ScrollView
    private lateinit var input: EditText
    private lateinit var sendBtn: TextView
    private lateinit var micBtn: TextView
    private lateinit var statusTv: TextView
    private lateinit var typingTv: TextView
    // Call overlay widgets
    private lateinit var callOverlay: LinearLayout
    private lateinit var callNameTv: TextView
    private lateinit var callStatusTv: TextView
    private lateinit var callAvatarFrame: FrameLayout
    private var speakerOn = false

    private val handler = Handler(Looper.getMainLooper())
    private lateinit var db: Db
    private var netCall: InternetVoiceCall? = null
    private var inCall = false
    private var callAudioMuted = false
    private var callSpeaker = false
    private var pendingInitiate = true
    private var callId = -1L; private var callStart = 0L
    private var lastTypingSent = 0L

    private val statusTick = object : Runnable {
        override fun run() { updateStatus(); handler.postDelayed(this, 4000) }
    }
    private val typingHide = object : Runnable { override fun run() {
        typingTv.visibility = View.GONE; statusTv.visibility = View.VISIBLE
    }}

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Session.init(this)
        peerId   = intent.getStringExtra("peerId")   ?: ""; if (peerId.isEmpty()) { finish(); return }
        peerName = intent.getStringExtra("peerName") ?: "User"
        isGroup  = intent.getBooleanExtra("isGroup", false)
        db = Db.get(this)
        buildUi()
        RabtaEvents.add(this)
        loadHistory()
        if (intent.getBooleanExtra("autoAnswer", false)) handler.post { startCall(false) }
    }

    override fun onResume() {
        super.onResume(); openPeer = peerId
        handler.post(statusTick); RabtaEvents.add(this)
        Thread { try { db.markAllRead(peerId) } catch (_: Exception) {} }.start()
        WsClient.sendRead(peerId, "all")
    }
    override fun onPause() { super.onPause(); openPeer = null; handler.removeCallbacks(statusTick) }
    override fun onDestroy() {
        endCall(); RabtaEvents.remove(this)
        Thread { try { db.clearUnread(peerId) } catch (_: Exception) {} }.start()
        super.onDestroy()
    }

    private fun dp(n: Int) = (n * resources.displayMetrics.density).toInt()
    private fun pill(c: Int, r: Int = 999) = GradientDrawable().apply { setColor(c); cornerRadius = dp(r).toFloat() }
    private fun oval(c: Int) = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(c) }
    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()
    private fun fmtTime(t: Long) = SimpleDateFormat("HH:mm", Locale.getDefault()).format(Date(t))

    private fun avatar(name: String, sz: Int): TextView {
        val cols = listOf(0xFFE53935,0xFF9C27B0,0xFF3F51B5,0xFF009688,0xFF43A047,0xFFFF5722,0xFF607D8B)
        return TextView(this).apply {
            text = name.filter { it.isLetterOrDigit() }.take(1).uppercase().ifEmpty { "?" }
            textSize = sz*0.38f; typeface = Typeface.DEFAULT_BOLD; setTextColor(Color.WHITE); gravity = Gravity.CENTER
            background = oval(cols[(name.hashCode() and 0x7FFFFFFF)%cols.size].toInt())
        }
    }

    private fun buildUi() {
        try { window.statusBarColor = 0xFF075E54.toInt() } catch (_: Exception) {}
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        setContentView(root)

        // ── Header ──
        val hdr = LinearLayout(this).apply { orientation=LinearLayout.HORIZONTAL; gravity=Gravity.CENTER_VERTICAL; setBackgroundColor(GREEN); setPadding(dp(6),dp(8),dp(10),dp(8)) }
        hdr.addView(TextView(this).apply { text="←"; textSize=22f; setTextColor(Color.WHITE); setPadding(dp(4),dp(4),dp(8),dp(4)); isClickable=true; setOnClickListener{finish()} })
        hdr.addView(avatar(peerName, dp(40)), LinearLayout.LayoutParams(dp(40),dp(40)))
        val hdrCol = LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; setPadding(dp(10),0,0,0) }
        hdrCol.addView(TextView(this).apply { text=peerName; textSize=17f; typeface=Typeface.DEFAULT_BOLD; setTextColor(Color.WHITE) })
        val subRow = LinearLayout(this).apply { orientation=LinearLayout.VERTICAL }
        statusTv  = TextView(this).apply { textSize=12f; setTextColor(0xCCFFFFFF.toInt()) }
        typingTv  = TextView(this).apply { textSize=12f; setTextColor(0xCCFFFFFF.toInt()); text="typing..."; visibility=View.GONE }
        subRow.addView(statusTv); subRow.addView(typingTv)
        hdrCol.addView(subRow)
        hdr.addView(hdrCol, LinearLayout.LayoutParams(0,ViewGroup.LayoutParams.WRAP_CONTENT,1f))
        if (!isGroup) hdr.addView(headerBtn("📞") { startCall(true) })
        hdr.addView(headerBtn("🎥") { startVideoCall() })
        root.addView(hdr)

        // ── Call overlay (WhatsApp style) ──
        callOverlay = LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; setBackgroundColor(DARK); visibility=View.GONE }
        // Top: name + status
        val callTop = LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; gravity=Gravity.CENTER; setPadding(0,dp(56),0,0) }
        callNameTv = TextView(this).apply { text=peerName; textSize=28f; typeface=Typeface.DEFAULT_BOLD; setTextColor(Color.WHITE); gravity=Gravity.CENTER }
        callStatusTv = TextView(this).apply { textSize=14f; setTextColor(0xBBFFFFFF.toInt()); gravity=Gravity.CENTER; setPadding(0,dp(6),0,0) }
        callTop.addView(callNameTv); callTop.addView(callStatusTv)
        callOverlay.addView(callTop)
        // Center: avatar
        callAvatarFrame = FrameLayout(this)
        callAvatarFrame.addView(avatar(peerName, dp(160)), FrameLayout.LayoutParams(dp(160),dp(160)).apply { gravity=Gravity.CENTER })
        callOverlay.addView(callAvatarFrame, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,0,1f))
        // Bottom: button panel (WhatsApp style 2-row grid)
        val panel = LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; setBackgroundColor(DARK2); setPadding(dp(24),dp(24),dp(24),dp(48)) }
        val row1 = LinearLayout(this).apply { orientation=LinearLayout.HORIZONTAL; gravity=Gravity.CENTER }
        val speakerBtn = callBtn("🔊","Speaker") { toggleSpeaker(it) }
        val muteBtnLayout = callBtn("🎤","Mic") { toggleMute(it) }
        val vidBtn2 = callBtn("📹","Video") { startVideoCall() }
        row1.addView(speakerBtn, LinearLayout.LayoutParams(0,ViewGroup.LayoutParams.WRAP_CONTENT,1f))
        row1.addView(vidBtn2,    LinearLayout.LayoutParams(0,ViewGroup.LayoutParams.WRAP_CONTENT,1f))
        row1.addView(muteBtnLayout, LinearLayout.LayoutParams(0,ViewGroup.LayoutParams.WRAP_CONTENT,1f))
        val row2 = LinearLayout(this).apply { orientation=LinearLayout.HORIZONTAL; gravity=Gravity.CENTER; setPadding(0,dp(20),0,0) }
        val endBtnPanel = callBtnRed("📵","End") { endCall() }
        row2.addView(LinearLayout(this).apply {}, LinearLayout.LayoutParams(0,ViewGroup.LayoutParams.WRAP_CONTENT,1f))
        row2.addView(endBtnPanel, LinearLayout.LayoutParams(0,ViewGroup.LayoutParams.WRAP_CONTENT,1f))
        row2.addView(LinearLayout(this).apply {}, LinearLayout.LayoutParams(0,ViewGroup.LayoutParams.WRAP_CONTENT,1f))
        panel.addView(row1); panel.addView(row2)
        callOverlay.addView(panel)
        root.addView(callOverlay)

        // ── Chat area ──
        chatScroll = ScrollView(this).apply { setBackgroundColor(BEIGE) }
        chatBox = LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; setPadding(dp(10),dp(8),dp(10),dp(8)) }
        chatScroll.addView(chatBox)
        root.addView(chatScroll, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,0,1f))

        // ── Input bar ──
        val bar = LinearLayout(this).apply { orientation=LinearLayout.HORIZONTAL; gravity=Gravity.BOTTOM; setBackgroundColor(0xFFF0F0F0.toInt()); setPadding(dp(6),dp(6),dp(6),dp(6)) }
        bar.addView(headerBtn("📎") { pickImage() }.apply { background=null })
        input = EditText(this).apply {
            hint="Paigham..."; textSize=16f; setTextColor(TXT); setHintTextColor(0xFFAAAAAA.toInt()); maxLines=5
            background = GradientDrawable().apply { setColor(Color.WHITE); cornerRadius=dp(24).toFloat() }
            setPadding(dp(14),dp(10),dp(14),dp(10))
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE or InputType.TYPE_TEXT_FLAG_CAP_SENTENCES
            addTextChangedListener(object:TextWatcher{
                override fun beforeTextChanged(s:CharSequence?,a:Int,b:Int,c:Int){}
                override fun onTextChanged(s:CharSequence?,a:Int,b:Int,c:Int){
                    val has = !s.isNullOrBlank()
                    sendBtn.visibility = if(has) View.VISIBLE else View.GONE
                    micBtn.visibility  = if(has) View.GONE   else View.VISIBLE
                    val now = System.currentTimeMillis()
                    if (has && now - lastTypingSent > 2500) { lastTypingSent=now; handler.postDelayed({ WsClient.sendTyping(peerId) }, 300) }
                }
                override fun afterTextChanged(s:Editable?){}
            })
        }
        bar.addView(input, LinearLayout.LayoutParams(0,ViewGroup.LayoutParams.WRAP_CONTENT,1f).apply { marginStart=dp(4); marginEnd=dp(4) })
        sendBtn = TextView(this).apply {
            text="➤"; textSize=20f; setTextColor(Color.WHITE); gravity=Gravity.CENTER
            background=oval(GREEN2); isClickable=true; setOnClickListener{sendMsg()}; visibility=View.GONE
        }
        bar.addView(sendBtn, LinearLayout.LayoutParams(dp(46),dp(46)))
        micBtn = TextView(this).apply {
            text="🎤"; textSize=20f; gravity=Gravity.CENTER; background=oval(GREEN2)
            setOnTouchListener { _,ev -> when(ev.action){ MotionEvent.ACTION_DOWN->{ checkAudioPermission{startVoiceRecord()}; true }; MotionEvent.ACTION_UP,MotionEvent.ACTION_CANCEL->{ stopVoiceRecord(ev.action==MotionEvent.ACTION_UP); true }; else->false } }
        }
        bar.addView(micBtn, LinearLayout.LayoutParams(dp(46),dp(46)))
        root.addView(bar)
    }

    // WhatsApp-style call button in panel
    private fun callBtn(icon: String, label: String, onClick: (TextView) -> Unit): LinearLayout {
        val col = LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; gravity=Gravity.CENTER }
        val btn = TextView(this).apply { text=icon; textSize=24f; gravity=Gravity.CENTER; background=oval(GRAY_BTN); isClickable=true }
        btn.setOnClickListener { onClick(btn) }
        col.addView(btn, LinearLayout.LayoutParams(dp(60),dp(60)))
        col.addView(TextView(this).apply { this.text=label; textSize=12f; setTextColor(0xCCFFFFFF.toInt()); gravity=Gravity.CENTER; setPadding(0,dp(6),0,0) })
        return col
    }
    private fun callBtnRed(icon: String, label: String, onClick: () -> Unit): LinearLayout {
        val col = LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; gravity=Gravity.CENTER }
        col.addView(TextView(this).apply { text=icon; textSize=24f; gravity=Gravity.CENTER; background=oval(RED); isClickable=true; setOnClickListener{onClick()} }, LinearLayout.LayoutParams(dp(68),dp(68)))
        col.addView(TextView(this).apply { this.text=label; textSize=12f; setTextColor(0xCCFFFFFF.toInt()); gravity=Gravity.CENTER; setPadding(0,dp(6),0,0) })
        return col
    }
    private fun headerBtn(icon: String, onClick: () -> Unit) = TextView(this).apply { text=icon; textSize=20f; gravity=Gravity.CENTER; setPadding(dp(8),dp(4),dp(8),dp(4)); isClickable=true; setOnClickListener{onClick()} }

    // ── Chat history ──
    private fun loadHistory() {
        Thread {
            val msgs = try { db.messages(peerId) } catch (_: Exception) { emptyList() }
            try { db.clearUnread(peerId) } catch (_: Exception) {}
            handler.post { chatBox.removeAllViews(); msgs.forEach { m -> addBubble(m.body,m.mine,fmtTime(m.sentAt),m.status,m.msgType,if(isGroup&&!m.mine)m.fromName else "") }; scrollBottom() }
        }.start()
    }

    // ── Message bubbles ──
    private fun addBubble(body: String, mine: Boolean, time: String, status: String="sent", msgType: String="text", sender: String="") {
        if (msgType=="text" && body.length>3000 && body.matches(Regex("[A-Za-z0-9+/=]+"))) return
        val wrap = LinearLayout(this).apply { orientation=LinearLayout.HORIZONTAL; gravity=if(mine) Gravity.END else Gravity.START }
        val bubble = LinearLayout(this).apply {
            orientation=LinearLayout.VERTICAL
            background = GradientDrawable().apply { setColor(if(mine) SENT else RECV); cornerRadius=dp(12).toFloat(); if(!mine) setStroke(dp(1),0x11000000) }
            setPadding(dp(10),dp(8),dp(10),dp(5)); elevation=dp(1).toFloat()
        }
        if (sender.isNotEmpty()) {
            val senderColors = listOf(0xFFE53935,0xFF9C27B0,0xFF3F51B5,0xFF009688)
            bubble.addView(TextView(this).apply { text=sender; textSize=13f; typeface=Typeface.DEFAULT_BOLD; setTextColor(senderColors[(sender.hashCode() and 0x7FFFFFFF)%senderColors.size].toInt()) })
        }
        when (msgType) {
            "image" -> {
                val bmp = MediaHelper.base64ToBitmap(body)
                if (bmp != null) {
                    val iv = ImageView(this).apply { setImageBitmap(bmp); scaleType=ImageView.ScaleType.CENTER_CROP; adjustViewBounds=true; background=pill(0xFFEEEEEE.toInt(),8) }
                    bubble.addView(iv, LinearLayout.LayoutParams(dp(220),dp(200)))
                } else bubble.addView(textLine("📷 Photo"))
            }
            "voice" -> bubble.addView(voiceNoteBubble(body, mine, time).also { return })  // voiceNote handles its own footer
            else    -> bubble.addView(textLine(body))
        }
        if (msgType != "voice") bubble.addView(msgFooter(time, mine, status))
        val maxW = (resources.displayMetrics.widthPixels * 0.78).toInt()
        wrap.addView(bubble, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT,ViewGroup.LayoutParams.WRAP_CONTENT).apply {
            topMargin=dp(2); bottomMargin=dp(2)
            if (mine) marginStart=resources.displayMetrics.widthPixels-maxW else marginEnd=resources.displayMetrics.widthPixels-maxW
        })
        chatBox.addView(wrap, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,ViewGroup.LayoutParams.WRAP_CONTENT))
    }

    // WhatsApp-style voice note
    private fun voiceNoteBubble(body: String, mine: Boolean, time: String): View {
        val outer = LinearLayout(this).apply {
            orientation=LinearLayout.HORIZONTAL; gravity=Gravity.START
        }
        val bubble = LinearLayout(this).apply {
            orientation=LinearLayout.VERTICAL
            background = GradientDrawable().apply { setColor(if(mine) SENT else RECV); cornerRadius=dp(12).toFloat(); if(!mine) setStroke(dp(1),0x11000000) }
            setPadding(dp(12),dp(10),dp(12),dp(6)); elevation=dp(1).toFloat()
        }
        // Row: play + waveform + duration
        val row = LinearLayout(this).apply { orientation=LinearLayout.HORIZONTAL; gravity=Gravity.CENTER_VERTICAL }
        var playing = false; var player: android.media.MediaPlayer? = null
        val playBtn = TextView(this).apply {
            text="▶"; textSize=20f; setTextColor(if(mine) 0xFF075E54.toInt() else GREEN)
            background=oval(if(mine) 0x33128C7E else 0x33128C7E); gravity=Gravity.CENTER
            setPadding(dp(10),dp(10),dp(10),dp(10))
            isClickable=true; setOnClickListener {
                if (playing) { player?.stop(); player?.release(); player=null; playing=false; text="▶" }
                else { player=MediaHelper.playVoice(context,body); if(player!=null){playing=true; text="⏸"; player?.setOnCompletionListener{playing=false;text="▶";player=null}} }
            }
        }
        row.addView(playBtn, LinearLayout.LayoutParams(dp(42),dp(42)).apply { marginEnd=dp(8) })
        // Waveform bars (static, seeded from body hash)
        val waveCol = LinearLayout(this).apply { orientation=LinearLayout.HORIZONTAL; gravity=Gravity.BOTTOM }
        val barHeights = listOf(8,18,12,28,22,16,30,20,14,26,18,12,24,32,18,14,22,28,16,20)
        val barColor = if (mine) 0xFF128C7E.toInt() else 0xFF667781.toInt()
        val barColorPlayed = if (mine) 0xFF075E54.toInt() else GREEN
        barHeights.forEach { h ->
            waveCol.addView(View(this).apply { background=pill(barColor,2) }, LinearLayout.LayoutParams(dp(3),(h*resources.displayMetrics.density).toInt()).apply { marginEnd=dp(2) })
        }
        row.addView(waveCol, LinearLayout.LayoutParams(0,dp(36),1f))
        // Duration estimate
        val durSec = maxOf(1, body.length * 3 / 4 / 4000)
        row.addView(TextView(this).apply {
            text=" 0:${durSec.toString().padStart(2,'0')}"; textSize=12f; setTextColor(SUB); setPadding(dp(6),0,0,0)
        })
        bubble.addView(row)
        bubble.addView(msgFooter(time, mine, "sent"))
        val maxW = (resources.displayMetrics.widthPixels * 0.78).toInt()
        val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT,ViewGroup.LayoutParams.WRAP_CONTENT).apply {
            topMargin=dp(2); bottomMargin=dp(2)
            if (mine) marginStart=resources.displayMetrics.widthPixels-maxW else marginEnd=resources.displayMetrics.widthPixels-maxW
        }
        val wrap = LinearLayout(this).apply { orientation=LinearLayout.HORIZONTAL; gravity=if(mine) Gravity.END else Gravity.START }
        wrap.addView(bubble, lp)
        chatBox.addView(wrap, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,ViewGroup.LayoutParams.WRAP_CONTENT))
        return View(this) // dummy return (bubble added directly)
    }

    private fun textLine(t: String) = TextView(this).apply { text=t; textSize=15f; setTextColor(TXT); setLineSpacing(0f,1.2f) }
    private fun msgFooter(time: String, mine: Boolean, status: String) = LinearLayout(this).apply {
        orientation=LinearLayout.HORIZONTAL; gravity=Gravity.END or Gravity.BOTTOM; setPadding(dp(4),dp(2),0,0)
        addView(TextView(this@ChatActivity).apply { this.text=time; textSize=11f; setTextColor(SUB) })
        if (mine) addView(TextView(this@ChatActivity).apply {
            this.text = when(status){ "delivered","read"->" ✓✓"; "mesh"->" 📡"; else->" ✓" }
            textSize=11f; setTextColor(if(status=="read") GREEN2 else if(status=="delivered") GREEN else SUB)
        })
    }
    private fun scrollBottom() { handler.post { chatScroll.fullScroll(View.FOCUS_DOWN) } }
    private fun updateStatus() {
        val mesh = if (MeshBridge.running) " · 📡${MeshBridge.peersConnected}" else ""
        statusTv.text = if (WsClient.connected) "Online$mesh" else "Offline$mesh"
    }

    // ── Send ──
    private fun sendMsg() {
        val text = input.text.toString().trim(); if (text.isEmpty()) return
        sendContent(text, "text"); input.setText("")
    }
    private fun sendContent(body: String, msgType: String) {
        val msgId = ByteArray(6).also{SecureRandom().nextBytes(it)}.joinToString(""){ "%02X".format(it) }
        val t = System.currentTimeMillis()
        val viaNet  = if (isGroup) WsClient.sendGroupMsg(peerId,msgId,body,msgType) else WsClient.send(peerId,msgId,body,msgType)
        val viaMesh = if (!isGroup) MeshBridge.sendDirect(peerId,msgId,body) else false
        if (!viaNet && !viaMesh && msgType!="image" && msgType!="voice") { toast("Na internet hai na mesh"); return }
        val preview = when(msgType){ "image"->"📷 Photo"; "voice"->"🎤 Voice note"; else->body }
        addBubble(body,true,fmtTime(t),if(viaNet)"sent" else "mesh",msgType); scrollBottom()
        Thread { db.saveMessage(msgId,peerId,Session.id,body,t,true,if(viaNet)"sent" else "mesh",msgType); db.upsertConversation(peerId,peerName,preview,t,false,isGroup) }.start()
    }

    // ── Image picker ──
    private fun pickImage() { startActivityForResult(Intent(Intent.ACTION_PICK).apply{type="image/*"}, 101) }
    override fun onActivityResult(req:Int, res:Int, data:Intent?) {
        super.onActivityResult(req,res,data)
        if (req==101 && res==RESULT_OK) { val uri=data?.data?:return; toast("Photo compress ho rahi hai...")
            Thread { val b64=MediaHelper.imageToBase64(this,uri); if(b64!=null) handler.post{sendContent(b64,"image")} else handler.post{toast("Photo load nahi ho saki")} }.start() }
    }

    // ── Voice note ──
    private fun startVoiceRecord() { if(!hasMic()) return; toast("Recording... (chhodein to bhejna)"); MediaHelper.startRecording(this) }
    private fun stopVoiceRecord(send:Boolean) {
        if (send) { Thread { val r=MediaHelper.stopRecording(); if(r!=null) handler.post{sendContent(r.first,"voice")} else handler.post{toast("Recording fail")} }.start() }
        else MediaHelper.cancelRecording()
    }
    private fun hasMic() = ContextCompat.checkSelfPermission(this,Manifest.permission.RECORD_AUDIO)==PackageManager.PERMISSION_GRANTED
    private fun checkAudioPermission(then: ()->Unit) { if (hasMic()) then() else ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.RECORD_AUDIO),98) }

    // ── Voice Call ──
    private fun startCall(initiate: Boolean) {
        if (inCall) return
        if (!hasMic()) { pendingInitiate=initiate; checkAudioPermission{}; return }
        if (!WsClient.connected) { toast("Call ke liye internet chahiye"); return }
        inCall=true; callOverlay.visibility=View.VISIBLE
        callStatusTv.text = if(initiate) "Calling..." else "Connecting..."
        callStart=System.currentTimeMillis()
        Thread { callId=db.logCallStart(peerId,peerName,if(initiate)"outgoing" else "incoming") }.start()
        netCall = InternetVoiceCall(peerId){ msg -> handler.post { callStatusTv.text=msg } }
        netCall?.start(initiate)
    }
    private fun startVideoCall() {
        if (!WsClient.connected) { toast("Video call ke liye internet chahiye"); return }
        val cId = ByteArray(6).also{SecureRandom().nextBytes(it)}.joinToString(""){"%02X".format(it)}
        startActivity(Intent(this,VideoCallActivity::class.java).putExtra(VideoCallActivity.PEER_ID,peerId).putExtra(VideoCallActivity.PEER_NAME,peerName).putExtra(VideoCallActivity.IS_CALLER,true).putExtra(VideoCallActivity.CALL_ID,cId))
    }
    private fun toggleMute(btn: TextView) {
        callAudioMuted=!callAudioMuted; netCall?.let { } // setEnabled not available, silence by sending silence
        btn.text = if(callAudioMuted) "🔇" else "🎤"
        btn.background = oval(if(callAudioMuted) 0xFFEEEEEE.toInt() else GRAY_BTN)
    }
    private fun toggleSpeaker(btn: TextView) {
        callSpeaker=!callSpeaker
        try { val am=getSystemService(AUDIO_SERVICE) as AudioManager; am.isSpeakerphoneOn=callSpeaker } catch (_:Exception){}
        btn.text = if(callSpeaker) "🔊" else "🔈"
        btn.background = oval(if(callSpeaker) GREEN else GRAY_BTN)
    }
    private fun endCall(sendEnd:Boolean=true) {
        if (!inCall) return; inCall=false; netCall?.stop(sendEnd); netCall=null
        val dur=((System.currentTimeMillis()-callStart)/1000).toInt()
        if (callId>0&&dur>1) Thread{db.logCallEnd(callId,dur)}.start(); callId=-1L
        handler.post { callOverlay.visibility=View.GONE }
    }

    override fun onRequestPermissionsResult(r:Int, p:Array<out String>, g:IntArray) {
        val ok = g.isNotEmpty()&&g[0]==PackageManager.PERMISSION_GRANTED
        when(r) { 99->if(ok) startCall(pendingInitiate) else toast("Mic permission chahiye"); 98->if(ok) toast("Ab mic button hold karein") }
    }

    // ── RabtaEvents ──
    override fun onConnected()    { handler.post { updateStatus() } }
    override fun onDisconnected() { handler.post { updateStatus() } }
    override fun onMessage(fromId:String,fromName:String,msgId:String,body:String,t:Long,msgType:String,groupId:String) {
        val match = if(isGroup) groupId==peerId else fromId==peerId; if (!match) return
        handler.post { addBubble(body,false,fmtTime(t),"received",msgType,if(isGroup&&fromId!=Session.id)fromName else ""); scrollBottom() }
        if (!isGroup) WsClient.sendRead(fromId,msgId)
    }
    override fun onAck(msgId:String,status:String) { Thread{db.updateStatus(msgId,status)}.start() }
    override fun onRead(msgId:String,byId:String) { if(byId==peerId) Thread{db.markAllRead(peerId)}.start() }
    override fun onTyping(fromId:String) {
        if (fromId!=peerId||isGroup) return
        handler.post { typingTv.visibility=View.VISIBLE; statusTv.visibility=View.GONE; handler.removeCallbacks(typingHide); handler.postDelayed(typingHide,3000) }
    }
    override fun onCallAudio(fromId:String,data:String) {
        if (fromId!=peerId) return
        if (netCall==null&&!inCall) { inCall=true; callOverlay.visibility=View.VISIBLE; callStatusTv.text="Incoming..."; netCall=InternetVoiceCall(peerId){msg->handler.post{callStatusTv.text=msg}}; netCall?.start(false) }
        netCall?.onAudio(data)
    }
    override fun onCallEnd(fromId:String) { if(fromId==peerId) handler.post{endCall(false);toast("Call khatam")} }
    override fun onVideoOffer(fromId:String,fromName:String,callId:String,sdp:String) {
        if (fromId!=peerId) return
        handler.post { startActivity(Intent(this,VideoCallActivity::class.java).putExtra(VideoCallActivity.PEER_ID,fromId).putExtra(VideoCallActivity.PEER_NAME,fromName).putExtra(VideoCallActivity.IS_CALLER,false).putExtra(VideoCallActivity.CALL_ID,callId).putExtra(VideoCallActivity.OFFER_SDP,sdp)) }
    }
    override fun onVideoEnd(callId:String) {}
}
