package com.irfan.rabta

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class ConversationListActivity : Activity(), RabtaEvents.Listener {

    private val G = 0xFF25D366.toInt()
    private val BG = 0xFF111B21.toInt()
    private val CARD = 0xFF1F2C34.toInt()
    private val SUB = 0xFF8696A0.toInt()
    private val TXT = 0xFFE9EDEF.toInt()
    private val DIV = 0xFF2A3942.toInt()

    private lateinit var convList: LinearLayout
    private lateinit var statusDot: View
    private lateinit var statusTv: TextView
    private val handler = Handler(Looper.getMainLooper())
    private lateinit var db: Db

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Session.init(this)
        if (!Session.loggedIn) { goAuth(); return }
        db = Db.get(this)
        buildUi()
        if (android.os.Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(android.Manifest.permission.POST_NOTIFICATIONS) != android.content.pm.PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(android.Manifest.permission.POST_NOTIFICATIONS), 7)
        }
        MessageService.start(this)
    }

    override fun onResume() { super.onResume(); RabtaEvents.add(this); loadConversations() }
    override fun onPause() { super.onPause(); RabtaEvents.remove(this) }
    override fun onDestroy() { RabtaEvents.remove(this); super.onDestroy() }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun round(c: Int, r: Int, stroke: Int? = null) = GradientDrawable().apply { setColor(c); cornerRadius = dp(r).toFloat(); if (stroke != null) setStroke(dp(1), stroke) }
    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()
    private fun fmtTime(t: Long): String {
        val now = System.currentTimeMillis()
        return if (now - t < 86400000) SimpleDateFormat("HH:mm", Locale.getDefault()).format(Date(t))
        else SimpleDateFormat("dd/MM", Locale.getDefault()).format(Date(t))
    }
    private fun avatar(name: String, size: Int): View {
        val colors = listOf(0xFF2196F3, 0xFF9C27B0, 0xFFE91E63, 0xFFFF5722, 0xFF009688, 0xFF3F51B5, 0xFF607D8B)
        val color = colors[(name.hashCode() and 0x7FFFFFFF) % colors.size].toInt()
        return TextView(this).apply {
            text = name.filter { it.isLetterOrDigit() }.take(1).uppercase().ifEmpty { "?" }
            textSize = (size * 0.38f); typeface = Typeface.DEFAULT_BOLD; setTextColor(Color.WHITE)
            gravity = Gravity.CENTER; background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(color) }
        }
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(BG) }
        setContentView(root)

        // Header
        val header = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setBackgroundColor(CARD); setPadding(dp(16), dp(12), dp(16), dp(12)) }
        header.addView(avatar(Session.name, dp(40)), LinearLayout.LayoutParams(dp(40), dp(40)))
        val headerText = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(12), 0, 0, 0) }
        headerText.addView(TextView(this).apply { text = "Rabta"; textSize = 20f; setTextColor(TXT); typeface = Typeface.DEFAULT_BOLD })
        headerText.addView(TextView(this).apply { text = "@${Session.username}"; textSize = 13f; setTextColor(SUB) })
        header.addView(headerText, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        // online dot
        statusDot = View(this).apply { background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(0xFF3C3C3C.toInt()) } }
        statusTv = TextView(this).apply { textSize = 12f; setTextColor(SUB); setPadding(dp(6), 0, 0, 0) }
        header.addView(statusDot, LinearLayout.LayoutParams(dp(10), dp(10)).apply { marginEnd = dp(4) })
        header.addView(statusTv)
        root.addView(header)

        val scroll = ScrollView(this).apply { isFillViewport = true }
        val body = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        scroll.addView(body)

        // New chat button
        val newBtn = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
            setBackgroundColor(CARD); setPadding(dp(16), dp(14), dp(16), dp(14))
        }
        newBtn.addView(TextView(this).apply {
            text = "+"; textSize = 24f; setTextColor(G); gravity = Gravity.CENTER
            background = round(0xFF0D2318.toInt(), 22); setPadding(dp(2), 0, dp(2), 0)
        }, LinearLayout.LayoutParams(dp(44), dp(44)))
        newBtn.addView(TextView(this).apply { text = "New chat"; textSize = 16f; setTextColor(TXT); setPadding(dp(14), 0, 0, 0) })
        newBtn.isClickable = true; newBtn.setOnClickListener { showNewChat() }
        body.addView(newBtn)
        body.addView(View(this).apply { setBackgroundColor(DIV) }, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(1)))

        // Conversation list
        convList = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        body.addView(convList)
        root.addView(scroll, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
    }

    private fun loadConversations() {
        Thread {
            val convs = db.conversations()
            handler.post {
                convList.removeAllViews()
                if (convs.isEmpty()) {
                    convList.addView(TextView(this).apply {
                        text = "\n\nKisi ko dhundhein:\n'+ New chat' mein jakar username type karein"; textSize = 15f; setTextColor(SUB); gravity = Gravity.CENTER; setPadding(0, dp(40), 0, 0)
                    })
                    return@post
                }
                convs.forEach { conv -> convList.addView(convRow(conv)); convList.addView(View(this).apply { setBackgroundColor(DIV) }, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(1)).apply { marginStart = dp(72) }) }
            }
        }.start()
    }

    private fun convRow(conv: Db.Conversation): View {
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setPadding(dp(16), dp(12), dp(16), dp(12)); setBackgroundColor(CARD) }
        row.addView(avatar(conv.peerName, dp(50)), LinearLayout.LayoutParams(dp(50), dp(50)))
        val mid = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(14), 0, dp(8), 0) }
        mid.addView(TextView(this).apply { text = conv.peerName; textSize = 17f; setTextColor(TXT); typeface = Typeface.DEFAULT_BOLD })
        mid.addView(TextView(this).apply { text = conv.lastMsg; textSize = 14f; setTextColor(SUB); maxLines = 1 })
        row.addView(mid, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        val right = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.END or Gravity.TOP }
        right.addView(TextView(this).apply { text = if (conv.lastTime > 0) fmtTime(conv.lastTime) else ""; textSize = 12f; setTextColor(SUB) })
        if (conv.unread > 0) right.addView(TextView(this).apply {
            text = conv.unread.toString(); textSize = 12f; typeface = Typeface.DEFAULT_BOLD; setTextColor(Color.BLACK)
            gravity = Gravity.CENTER; background = round(G, 12); setPadding(dp(7), dp(2), dp(7), dp(2))
        }, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = dp(4) })
        row.addView(right)
        row.isClickable = true; row.setOnClickListener { openChat(conv.peerId, conv.peerName) }
        return row
    }

    private fun showNewChat() {
        val dl = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(24), dp(24), dp(24), dp(16)); setBackgroundColor(CARD) }
        val inp = EditText(this).apply {
            hint = "@username"; textSize = 16f; setTextColor(TXT); setHintTextColor(SUB); setSingleLine(true)
            background = round(0xFF2A3942.toInt(), 12); setPadding(dp(14), dp(12), dp(14), dp(12))
            inputType = InputType.TYPE_CLASS_TEXT
        }
        val status = TextView(this).apply { textSize = 14f; setTextColor(SUB) }
        dl.addView(TextView(this).apply { text = "New chat"; textSize = 20f; setTextColor(TXT); typeface = Typeface.DEFAULT_BOLD; setPadding(0, 0, 0, dp(16)) })
        dl.addView(TextView(this).apply { text = "Username"; textSize = 13f; setTextColor(SUB) })
        dl.addView(inp, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = dp(8); bottomMargin = dp(8) })
        dl.addView(status)
        val dlgBtns = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.END }
        val cancel = TextView(this).apply { text = "Cancel"; textSize = 15f; setTextColor(SUB); setPadding(dp(12), dp(12), dp(12), dp(12)) }
        val find = TextView(this).apply { text = "Find"; textSize = 15f; setTextColor(G); typeface = Typeface.DEFAULT_BOLD; setPadding(dp(12), dp(12), dp(4), dp(12)) }
        dlgBtns.addView(cancel); dlgBtns.addView(find); dl.addView(dlgBtns)
        val dlg = android.app.AlertDialog.Builder(this).setView(dl).create()
        dlg.window?.setBackgroundDrawable(round(CARD, 16))
        cancel.setOnClickListener { dlg.dismiss() }
        find.setOnClickListener {
            val un = inp.text.toString().trim().lowercase()
            if (un.isEmpty()) return@setOnClickListener
            status.text = "Dhoondh raha hoon..."
            WsClient.findUser(Session.serverUrl, un, Session.token) { ok, msg, data ->
                if (ok && data != null) {
                        try { dlg.dismiss() } catch (_: Exception) {}
                        val pid = data.optString("id")
                        val pname = data.optString("name").ifEmpty { data.optString("username") }
                        if (pid.isNotEmpty()) openChat(pid, pname)
                        else status.text = "User ID nahi mila"
                    }
                else status.text = msg
            }
        }
        dlg.show()
    }

    private fun openChat(peerId: String, peerName: String) {
        startActivity(Intent(this, ChatActivity::class.java).putExtra("peerId", peerId).putExtra("peerName", peerName))
    }

    // RabtaEvents.Listener
    override fun onConnected() { statusDot.background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(G) }; statusTv.text = "Online" }
    override fun onDisconnected() { statusDot.background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(0xFF3C3C3C.toInt()) }; statusTv.text = "Offline" }
    override fun onMessage(fromId: String, fromName: String, msgId: String, body: String, t: Long) {
        handler.postDelayed({ loadConversations() }, 400)
    }

    private fun goAuth() { startActivity(Intent(this, AuthActivity::class.java)); finish() }
}
