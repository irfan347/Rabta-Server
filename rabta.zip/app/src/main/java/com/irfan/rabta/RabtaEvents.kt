package com.irfan.rabta

import android.os.Handler
import android.os.Looper

/** Simple pub/sub so Service and Activities share WebSocket events without conflict. */
object RabtaEvents {
    interface Listener {
        fun onMessage(fromId: String, fromName: String, msgId: String, body: String, t: Long) {}
        fun onAck(msgId: String, status: String) {}
        fun onIncomingCall(fromId: String, fromName: String) {}
        fun onCallAudio(fromId: String, data: String) {}
        fun onCallEnd(fromId: String) {}
        fun onConnected() {}
        fun onDisconnected() {}
    }
    private val listeners = mutableListOf<Listener>()
    private val handler = Handler(Looper.getMainLooper())

    @Synchronized fun add(l: Listener)    { if (!listeners.contains(l)) listeners.add(l) }
    @Synchronized fun remove(l: Listener) { listeners.remove(l) }

    private fun fire(block: Listener.() -> Unit) {
        handler.post { synchronized(listeners) { listeners.toList() }.forEach { it.block() } }
    }

    fun postMessage(fromId: String, fromName: String, msgId: String, body: String, t: Long) = fire { onMessage(fromId, fromName, msgId, body, t) }
    fun postAck(msgId: String, status: String)              = fire { onAck(msgId, status) }
    fun postIncomingCall(fromId: String, fromName: String)  = fire { onIncomingCall(fromId, fromName) }
    fun postCallAudio(fromId: String, data: String)         = fire { onCallAudio(fromId, data) }
    fun postCallEnd(fromId: String)                         = fire { onCallEnd(fromId) }
    fun postConnected()                                     = fire { onConnected() }
    fun postDisconnected()                                  = fire { onDisconnected() }
}
