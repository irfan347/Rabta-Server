package com.irfan.rabta

import android.annotation.SuppressLint
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.AudioTrack
import android.media.MediaRecorder
import android.os.Handler
import android.os.Looper
import android.util.Base64
import org.json.JSONObject
import java.util.concurrent.LinkedBlockingQueue

/**
 * Internet voice call over the main WebSocket.
 * Mic -> 40ms frames (base64) -> server relays -> other phone -> speaker.
 * Old frames are dropped when behind, so delay never piles up.
 */
class InternetVoiceCall(private val peerId: String, private val onStatus: (String) -> Unit) {
    private val sampleRate = 8000
    private val frameBytes = 640
    private val maxQueue = 6
    private val recMin = AudioRecord.getMinBufferSize(sampleRate, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT).coerceAtLeast(frameBytes * 2)
    private val playMin = AudioTrack.getMinBufferSize(sampleRate, AudioFormat.CHANNEL_OUT_MONO, AudioFormat.ENCODING_PCM_16BIT).coerceAtLeast(frameBytes * 2)

    private var record: AudioRecord? = null
    private var track: AudioTrack? = null
    private val queue = LinkedBlockingQueue<ByteArray>()
    private val handler = Handler(Looper.getMainLooper())
    @Volatile var running = false; private set
    @Volatile private var heardOther = false

    /** initiate=true: I'm calling (rings the other phone). false: I answered. */
    fun start(initiate: Boolean) {
        if (running) return
        running = true
        if (initiate) {
            WsClient.sendRaw(JSONObject().put("type", "call_init").put("to", peerId).toString())
            onStatus("Ring ho rahi hai...")
        } else onStatus("Connecting...")
        startPlayback()
        startCapture()
    }

    /** Audio frame from the other phone (base64). */
    fun onAudio(b64: String) {
        if (!running) return
        if (!heardOther) { heardOther = true; handler.post { onStatus("Connected - bolein") } }
        val data = try { Base64.decode(b64, Base64.NO_WRAP) } catch (_: Exception) { return }
        while (queue.size >= maxQueue) queue.poll()
        queue.offer(data)
    }

    @SuppressLint("MissingPermission")
    private fun startCapture() {
        record = try {
            AudioRecord(MediaRecorder.AudioSource.VOICE_COMMUNICATION, sampleRate,
                AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT, recMin)
        } catch (_: Exception) { null }
        try { record?.startRecording() } catch (_: Exception) {}
        Thread {
            val buf = ByteArray(frameBytes)
            while (running) {
                val n = record?.read(buf, 0, buf.size) ?: -1
                if (n > 0) {
                    val enc = Base64.encodeToString(buf, 0, n, Base64.NO_WRAP)
                    WsClient.sendRaw(JSONObject().put("type", "call_audio").put("to", peerId).put("data", enc).toString())
                } else if (n < 0) { try { Thread.sleep(20) } catch (_: Exception) {} }
            }
        }.also { it.isDaemon = true; it.start() }
    }

    private fun startPlayback() {
        track = AudioTrack.Builder()
            .setAudioAttributes(AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_VOICE_COMMUNICATION)
                .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH).build())
            .setAudioFormat(AudioFormat.Builder()
                .setSampleRate(sampleRate)
                .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                .setChannelMask(AudioFormat.CHANNEL_OUT_MONO).build())
            .setBufferSizeInBytes(playMin)
            .setTransferMode(AudioTrack.MODE_STREAM).build()
        try { track?.play() } catch (_: Exception) {}
        Thread {
            while (running) {
                val f = try { queue.take() } catch (_: InterruptedException) { break }
                try { track?.write(f, 0, f.size) } catch (_: Exception) {}
            }
        }.also { it.isDaemon = true; it.start() }
    }

    /** sendEnd=false when the OTHER side hung up (don't echo it back). */
    fun stop(sendEnd: Boolean = true) {
        if (!running) return
        running = false
        if (sendEnd) WsClient.sendRaw(JSONObject().put("type", "call_end").put("to", peerId).toString())
        queue.offer(ByteArray(0)) // wake the playback thread
        try { record?.stop(); record?.release() } catch (_: Exception) {}
        try { track?.stop(); track?.release() } catch (_: Exception) {}
        record = null; track = null; queue.clear()
    }
}
