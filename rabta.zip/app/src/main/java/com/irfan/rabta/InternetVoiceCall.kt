package com.irfan.rabta

import android.annotation.SuppressLint
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioManager
import android.media.AudioRecord
import android.media.AudioTrack
import android.media.MediaRecorder
import android.os.Handler
import android.os.Looper
import android.util.Base64
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.Response
import okhttp3.WebSocket
import okhttp3.WebSocketListener
import org.json.JSONObject
import java.util.concurrent.LinkedBlockingQueue
import java.util.concurrent.TimeUnit

/**
 * Voice call over the internet:
 * Mic → base64 frames → WebSocket server → other phone → speaker
 * Runs alongside WsClient (separate WebSocket dedicated to low-latency audio)
 */
class InternetVoiceCall(
    private val serverUrl: String,
    private val token: String,
    private val peerId: String,
    private val onStatus: (String) -> Unit
) {
    private val sampleRate = 8000
    private val frameBytes = 640 // 40ms at 8kHz 16-bit
    private val maxQueue   = 6   // ~240ms max buffer

    private val recMin = AudioRecord.getMinBufferSize(
        sampleRate, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT
    ).coerceAtLeast(frameBytes * 2)
    private val playMin = AudioTrack.getMinBufferSize(
        sampleRate, AudioFormat.CHANNEL_OUT_MONO, AudioFormat.ENCODING_PCM_16BIT
    ).coerceAtLeast(frameBytes * 2)

    private val http = OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS)
        .pingInterval(10, TimeUnit.SECONDS)
        .build()
    private var ws: WebSocket? = null
    private var record: AudioRecord? = null
    private var track: AudioTrack? = null
    private val queue = LinkedBlockingQueue<ByteArray>()
    @Volatile var running = false; private set
    @Volatile var connected = false; private set
    private val handler = Handler(Looper.getMainLooper())

    fun start() {
        if (running) return
        running = true
        val url = serverUrl.replace("https://","wss://").replace("http://","ws://") + "/ws-call"
        val req = Request.Builder().url(url)
            .header("Authorization", "Bearer $token").build()
        ws = http.newWebSocket(req, object : WebSocketListener() {
            override fun onOpen(ws: WebSocket, response: Response) {
                connected = true
                // Tell the server who we're calling
                ws.send(JSONObject().put("type","call_init").put("to", peerId).toString())
                handler.post { onStatus("Connected - bolein!") }
                startCapture()
            }
            override fun onMessage(ws: WebSocket, text: String) {
                val o = try { JSONObject(text) } catch (_: Exception) { return }
                if (o.optString("type") == "call_audio") {
                    val data = try { Base64.decode(o.optString("data"), Base64.NO_WRAP) } catch (_: Exception) { return }
                    while (queue.size >= maxQueue) queue.poll() // drop old frames
                    queue.offer(data)
                } else if (o.optString("type") == "call_end") {
                    handler.post { onStatus("Call khatam ho gayi"); stop() }
                }
            }
            override fun onFailure(ws: WebSocket, t: Throwable, response: Response?) {
                connected = false
                handler.post { onStatus("Call connect nahi ho saki: ${t.message}") }
                stop()
            }
            override fun onClosed(ws: WebSocket, code: Int, reason: String) {
                connected = false; handler.post { onStatus("Call khatam") }
            }
        })
        startPlayback()
    }

    @SuppressLint("MissingPermission")
    private fun startCapture() {
        record = AudioRecord(
            MediaRecorder.AudioSource.VOICE_COMMUNICATION, sampleRate,
            AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT, recMin
        )
        try { record?.startRecording() } catch (_: Exception) {}
        Thread {
            val buf = ByteArray(frameBytes)
            while (running) {
                val n = record?.read(buf, 0, buf.size) ?: -1
                if (n > 0 && connected) {
                    val encoded = Base64.encodeToString(buf.copyOf(n), Base64.NO_WRAP)
                    ws?.send(JSONObject().put("type","call_audio").put("to",peerId).put("data",encoded).toString())
                }
            }
        }.also { it.isDaemon = true; it.start() }
    }

    private fun startPlayback() {
        track = AudioTrack.Builder()
            .setAudioAttributes(AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_VOICE_COMMUNICATION)
                .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH).build())
            .setAudioFormat(AudioFormat.Builder()
                .setSampleRate(sampleRate)
                .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                .setChannelMask(AudioFormat.CHANNEL_OUT_MONO).build())
            .setBufferSizeInBytes(playMin)
            .setTransferMode(AudioTrack.MODE_STREAM).build()
        try { track?.play() } catch (_: Exception) {}
        Thread {
            while (running) {
                val frame = try { queue.take() } catch (_: InterruptedException) { break }
                try { track?.write(frame, 0, frame.size) } catch (_: Exception) {}
            }
        }.also { it.isDaemon = true; it.start() }
    }

    fun stop() {
        if (!running) return
        running = false; connected = false
        try { ws?.send(JSONObject().put("type","call_end").put("to",peerId).toString()) } catch (_: Exception) {}
        try { ws?.close(1000,"bye") } catch (_: Exception) {}
        try { record?.stop(); record?.release() } catch (_: Exception) {}
        try { track?.stop(); track?.release() } catch (_: Exception) {}
        record = null; track = null; ws = null; queue.clear()
    }
}
