package com.irfan.rabta

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Matrix
import android.media.ExifInterface
import android.media.MediaPlayer
import android.media.MediaRecorder
import android.net.Uri
import android.util.Base64
import java.io.ByteArrayOutputStream
import java.io.File

object MediaHelper {

    /** Compress image from URI to base64 JPEG (max 800px, ~60KB). */
    fun imageToBase64(ctx: Context, uri: Uri): String? = try {
        val stream = ctx.contentResolver.openInputStream(uri) ?: return null
        var bmp = BitmapFactory.decodeStream(stream)
        stream.close()
        // Correct orientation
        try {
            val exifStream = ctx.contentResolver.openInputStream(uri)!!
            val exif = ExifInterface(exifStream)
            val orient = exif.getAttributeInt(ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL)
            val matrix = Matrix()
            when (orient) {
                ExifInterface.ORIENTATION_ROTATE_90  -> matrix.postRotate(90f)
                ExifInterface.ORIENTATION_ROTATE_180 -> matrix.postRotate(180f)
                ExifInterface.ORIENTATION_ROTATE_270 -> matrix.postRotate(270f)
            }
            bmp = Bitmap.createBitmap(bmp, 0, 0, bmp.width, bmp.height, matrix, true)
            exifStream.close()
        } catch (_: Exception) {}
        // Scale down
        val maxPx = 800
        val scale = maxPx.toFloat() / maxOf(bmp.width, bmp.height)
        if (scale < 1f) bmp = Bitmap.createScaledBitmap(bmp, (bmp.width*scale).toInt(), (bmp.height*scale).toInt(), true)
        val out = ByteArrayOutputStream()
        bmp.compress(Bitmap.CompressFormat.JPEG, 75, out)
        Base64.encodeToString(out.toByteArray(), Base64.NO_WRAP)
    } catch (_: Exception) { null }

    fun base64ToBitmap(b64: String): Bitmap? = try {
        val bytes = Base64.decode(b64, Base64.NO_WRAP)
        BitmapFactory.decodeByteArray(bytes, 0, bytes.size)
    } catch (_: Exception) { null }

    // Voice note recording
    private var recorder: MediaRecorder? = null
    private var voiceFile: File? = null

    fun startRecording(ctx: Context) {
        try {
            val f = File(ctx.cacheDir, "voice_${System.currentTimeMillis()}.mp4")
            voiceFile = f
            recorder = MediaRecorder(ctx).apply {
                setAudioSource(MediaRecorder.AudioSource.MIC)
                setOutputFormat(MediaRecorder.OutputFormat.MPEG_4)
                setAudioEncoder(MediaRecorder.AudioEncoder.AAC)
                setAudioSamplingRate(16000)
                setAudioEncodingBitRate(32000)
                setOutputFile(f.absolutePath)
                prepare(); start()
            }
        } catch (_: Exception) { recorder = null }
    }

    /** Stop recording and return base64 encoded voice note. */
    fun stopRecording(): Pair<String, Int>? = try {
        val durationMs = recorder?.let {
            try { it.stop() } catch (_: Exception) {}
            it.release(); null
        }.let { System.currentTimeMillis() } // rough estimate; real duration below
        recorder = null
        val f = voiceFile ?: return null
        val bytes = f.readBytes(); f.delete()
        val base64 = Base64.encodeToString(bytes, Base64.NO_WRAP)
        val dur = try { MediaPlayer().run { setDataSource(f.absolutePath); prepare(); val d = duration; release(); d/1000 } } catch (_: Exception) { bytes.size / 4000 }
        base64 to dur
    } catch (_: Exception) { null }

    fun cancelRecording() { try { recorder?.stop() } catch (_: Exception) {}; recorder?.release(); recorder = null; voiceFile?.delete(); voiceFile = null }

    /** Play a base64 voice note. Returns a MediaPlayer (caller should release when done). */
    fun playVoice(ctx: Context, b64: String): MediaPlayer? = try {
        val f = File(ctx.cacheDir, "play_${System.currentTimeMillis()}.mp4")
        f.writeBytes(Base64.decode(b64, Base64.NO_WRAP))
        MediaPlayer().apply { setDataSource(f.absolutePath); prepare(); start(); setOnCompletionListener { f.delete(); release() } }
    } catch (_: Exception) { null }
}
