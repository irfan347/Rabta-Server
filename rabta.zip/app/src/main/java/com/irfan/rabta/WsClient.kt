package com.irfan.rabta

import android.content.Context
import android.os.Handler
import android.os.Looper
import okhttp3.Call
import okhttp3.Callback
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import okhttp3.Response
import okhttp3.WebSocket
import okhttp3.WebSocketListener
import org.json.JSONObject
import java.io.IOException
import java.util.concurrent.TimeUnit

/** Internet relay via WebSocket. Dispatches all events via RabtaEvents. */
object WsClient {

    private val http = OkHttpClient.Builder()
        .connectTimeout(90, TimeUnit.SECONDS)
        .readTimeout(90, TimeUnit.SECONDS)
        .pingInterval(25, TimeUnit.SECONDS)
        .build()
    private val handler = Handler(Looper.getMainLooper())
    private var ws: WebSocket? = null
    var connected = false; private set
    private var reconnectDelay = 2000L
    private var shouldConnect = false

    fun connect(session: Session) {
        if (session.serverUrl.isEmpty() || session.token.isEmpty()) return
        shouldConnect = true
        reconnectDelay = 2000L
        doConnect(session)
    }

    private fun doConnect(session: Session) {
        val url = session.serverUrl.replace("https://", "wss://").replace("http://", "ws://") + "/ws"
        val req = Request.Builder().url(url).header("Authorization", "Bearer ${session.token}").build()
        ws = http.newWebSocket(req, object : WebSocketListener() {
            override fun onOpen(ws: WebSocket, response: Response) {
                connected = true; reconnectDelay = 2000L
                handler.post { RabtaEvents.postConnected() }
            }
            override fun onMessage(ws: WebSocket, text: String) {
                val o = try { JSONObject(text) } catch (_: Exception) { return }
                handler.post { handle(o) }
            }
            override fun onFailure(ws: WebSocket, t: Throwable, response: Response?) {
                connected = false; handler.post { RabtaEvents.postDisconnected() }
                if (shouldConnect) handler.postDelayed({ doConnect(session) }, reconnectDelay.also { reconnectDelay = (it * 1.5).toLong().coerceAtMost(30000) })
            }
            override fun onClosed(ws: WebSocket, code: Int, reason: String) {
                connected = false; handler.post { RabtaEvents.postDisconnected() }
                if (shouldConnect) handler.postDelayed({ doConnect(session) }, reconnectDelay)
            }
        })
    }

    private fun handle(o: JSONObject) {
        when (o.optString("type")) {
            "msg"           -> RabtaEvents.postMessage(o.optString("from"), o.optString("fromName"), o.optString("id"), o.optString("body"), o.optLong("t", System.currentTimeMillis()))
            "ack"           -> RabtaEvents.postAck(o.optString("id"), o.optString("status"))
            "incoming_call" -> RabtaEvents.postIncomingCall(o.optString("from"), o.optString("fromName"))
            "call_audio"    -> RabtaEvents.postCallAudio(o.optString("from"), o.optString("data"))
            "call_end"      -> RabtaEvents.postCallEnd(o.optString("from"))
            "ready"         -> { /* already handled in onOpen */ }
        }
    }

    fun disconnect() { shouldConnect = false; ws?.close(1000, "bye"); ws = null; connected = false }

    fun send(toId: String, msgId: String, body: String): Boolean {
        if (!connected || ws == null) return false
        return ws!!.send(JSONObject().put("type","msg").put("id",msgId).put("to",toId).put("body",body).put("t",System.currentTimeMillis()).toString())
    }

    // ---------- HTTP helpers ----------
    fun register(ctx: Context, serverUrl: String, username: String, pin: String, name: String, onResult: (Boolean, String, JSONObject?) -> Unit) {
        val body = JSONObject().put("username", username).put("pin", pin).put("name", name).toString()
        httpPost(serverUrl, "/api/register", body, null, onResult)
    }

    fun login(ctx: Context, serverUrl: String, username: String, pin: String, onResult: (Boolean, String, JSONObject?) -> Unit) {
        val body = JSONObject().put("username", username).put("pin", pin).toString()
        httpPost(serverUrl, "/api/login", body, null, onResult)
    }

    fun findUser(serverUrl: String, username: String, token: String, onResult: (Boolean, String, JSONObject?) -> Unit) {
        val req = Request.Builder().url(serverUrl.trimEnd('/') + "/api/user/${username.lowercase()}")
            .header("Authorization", "Bearer $token").build()
        http.newCall(req).enqueue(object : Callback {
            override fun onFailure(call: Call, e: IOException) {
                val msg = when {
                    e.message?.contains("timeout", true) == true ->
                        "Server so gaya hai. 1 minute ruk kar dobara try karein (Render free tier issue)."
                    e.message?.contains("Unable to resolve", true) == true ->
                        "Server URL galat lagta hai. https:// sahi hai?"
                    else -> "Network error: ${e.message}"
                }
                handler.post { onResult(false, msg, null) }
            }
            override fun onResponse(call: Call, response: Response) {
                val body = response.body?.string() ?: ""
                val o = try { JSONObject(body) } catch (_: Exception) { JSONObject() }
                handler.post { if (response.isSuccessful) onResult(true, "ok", o) else onResult(false, o.optString("error", "Not found"), null) }
            }
        })
    }

    private fun httpPost(serverUrl: String, path: String, body: String, token: String?, onResult: (Boolean, String, JSONObject?) -> Unit) {
        val rb = body.toRequestBody("application/json".toMediaType())
        val reqB = Request.Builder().url(serverUrl.trimEnd('/') + path).post(rb)
        if (token != null) reqB.header("Authorization", "Bearer $token")
        http.newCall(reqB.build()).enqueue(object : Callback {
            override fun onFailure(call: Call, e: IOException) {
                val msg = when {
                    e.message?.contains("timeout", true) == true ->
                        "Server so gaya hai. 1 minute ruk kar dobara try karein (Render free tier issue)."
                    e.message?.contains("Unable to resolve", true) == true ->
                        "Server URL galat lagta hai. https:// sahi hai?"
                    else -> "Network error: ${e.message}"
                }
                handler.post { onResult(false, msg, null) }
            }
            override fun onResponse(call: Call, response: Response) {
                val b = response.body?.string() ?: ""
                val o = try { JSONObject(b) } catch (_: Exception) { JSONObject() }
                handler.post { if (response.isSuccessful) onResult(true, "ok", o) else onResult(false, o.optString("error", "Error"), null) }
            }
        })
    }
}
