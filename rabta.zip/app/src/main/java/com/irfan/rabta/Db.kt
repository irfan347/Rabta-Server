package com.irfan.rabta

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper

class Db(ctx: Context) : SQLiteOpenHelper(ctx, "rabta.db", null, 4) {

    data class Conversation(val peerId: String, val peerName: String, val lastMsg: String, val lastTime: Long, val unread: Int, val isGroup: Boolean = false)
    data class Message(val id: String, val convId: String, val fromId: String, val fromName: String, val body: String, val sentAt: Long, val mine: Boolean, val status: String, val msgType: String)
    data class Group(val id: String, val name: String, val members: List<String>)

    override fun onCreate(db: SQLiteDatabase) = createAll(db)
    override fun onUpgrade(db: SQLiteDatabase, o: Int, n: Int) {
        if (o < 4) {
            try { db.execSQL("ALTER TABLE messages ADD COLUMN from_name TEXT DEFAULT ''") } catch (_: Exception) {}
            try { db.execSQL("ALTER TABLE messages ADD COLUMN msg_type TEXT DEFAULT 'text'") } catch (_: Exception) {}
            try { db.execSQL("ALTER TABLE conversations ADD COLUMN is_group INTEGER DEFAULT 0") } catch (_: Exception) {}
            try { db.execSQL("CREATE TABLE IF NOT EXISTS calls(id INTEGER PRIMARY KEY AUTOINCREMENT, peer_id TEXT, peer_name TEXT, type TEXT, duration INTEGER DEFAULT 0, started_at INTEGER)") } catch (_: Exception) {}
            db.execSQL("CREATE TABLE IF NOT EXISTS groups(id TEXT PRIMARY KEY, name TEXT, members TEXT)")
        db.execSQL("CREATE TABLE IF NOT EXISTS calls(id INTEGER PRIMARY KEY AUTOINCREMENT, peer_id TEXT, peer_name TEXT, type TEXT, duration INTEGER DEFAULT 0, started_at INTEGER)")
        } else { db.execSQL("DROP TABLE IF EXISTS conversations"); db.execSQL("DROP TABLE IF EXISTS messages"); createAll(db) }
    }

    private fun createAll(db: SQLiteDatabase) {
        db.execSQL("CREATE TABLE IF NOT EXISTS conversations(peer_id TEXT PRIMARY KEY, peer_name TEXT, last_msg TEXT, last_time INTEGER DEFAULT 0, unread INTEGER DEFAULT 0, is_group INTEGER DEFAULT 0)")
        db.execSQL("CREATE TABLE IF NOT EXISTS messages(id TEXT PRIMARY KEY, conv_id TEXT, from_id TEXT, from_name TEXT DEFAULT '', body TEXT, sent_at INTEGER, mine INTEGER DEFAULT 0, status TEXT DEFAULT 'sent', msg_type TEXT DEFAULT 'text')")
        db.execSQL("CREATE INDEX IF NOT EXISTS idx_msg_conv ON messages(conv_id, sent_at)")
        db.execSQL("CREATE TABLE IF NOT EXISTS groups(id TEXT PRIMARY KEY, name TEXT, members TEXT)")
        db.execSQL("CREATE TABLE IF NOT EXISTS calls(id INTEGER PRIMARY KEY AUTOINCREMENT, peer_id TEXT, peer_name TEXT, type TEXT, duration INTEGER DEFAULT 0, started_at INTEGER)")
    }

    companion object {
        @Volatile private var INST: Db? = null
        fun get(ctx: Context) = INST ?: synchronized(this) { INST ?: Db(ctx.applicationContext).also { INST = it } }
    }

    fun upsertConversation(peerId: String, peerName: String, lastMsg: String, time: Long, incUnread: Boolean, isGroup: Boolean = false) {
        val cv = ContentValues().apply { put("peer_id",peerId);put("peer_name",peerName);put("last_msg",lastMsg.take(100));put("last_time",time);put("is_group", if(isGroup) 1 else 0) }
        writableDatabase.insertWithOnConflict("conversations", null, cv, SQLiteDatabase.CONFLICT_IGNORE)
        writableDatabase.execSQL("UPDATE conversations SET peer_name=?,last_msg=?,last_time=?,unread=unread+?,is_group=? WHERE peer_id=?",
            arrayOf(peerName, lastMsg.take(100), time, if (incUnread) 1 else 0, if (isGroup) 1 else 0, peerId))
    }

    fun clearUnread(peerId: String) = writableDatabase.execSQL("UPDATE conversations SET unread=0 WHERE peer_id=?", arrayOf(peerId))

    fun conversations(): List<Conversation> {
        val list = mutableListOf<Conversation>()
        readableDatabase.rawQuery("SELECT peer_id,peer_name,last_msg,last_time,unread,is_group FROM conversations ORDER BY last_time DESC", null).use { c ->
            while (c.moveToNext()) list.add(Conversation(c.getString(0), c.getString(1), c.getString(2) ?: "", c.getLong(3), c.getInt(4), c.getInt(5) == 1))
        }
        return list
    }

    fun saveIfNew(id: String, convId: String, fromId: String, fromName: String, body: String, sentAt: Long, mine: Boolean, status: String, msgType: String = "text"): Boolean {
        val cv = ContentValues().apply {
            put("id",id);put("conv_id",convId);put("from_id",fromId);put("from_name",fromName)
            put("body",body);put("sent_at",sentAt);put("mine",if(mine)1 else 0);put("status",status);put("msg_type",msgType)
        }
        return writableDatabase.insertWithOnConflict("messages", null, cv, SQLiteDatabase.CONFLICT_IGNORE) != -1L
    }

    fun saveMessage(id: String, convId: String, fromId: String, body: String, sentAt: Long, mine: Boolean, status: String = "sent", msgType: String = "text", fromName: String = "") {
        saveIfNew(id, convId, fromId, fromName, body, sentAt, mine, status, msgType)
    }

    fun messages(convId: String, limit: Int = 200): List<Message> {
        val list = mutableListOf<Message>()
        readableDatabase.rawQuery("SELECT id,conv_id,from_id,from_name,body,sent_at,mine,status,msg_type FROM messages WHERE conv_id=? ORDER BY sent_at ASC LIMIT ?",
            arrayOf(convId, limit.toString())).use { c ->
            while (c.moveToNext()) list.add(Message(c.getString(0), c.getString(1), c.getString(2), c.getString(3) ?: "", c.getString(4), c.getLong(5), c.getInt(6)==1, c.getString(7), c.getString(8) ?: "text"))
        }
        return list
    }

    fun updateStatus(msgId: String, status: String) = writableDatabase.execSQL("UPDATE messages SET status=? WHERE id=?", arrayOf(status, msgId))
    fun markAllRead(convId: String) = writableDatabase.execSQL("UPDATE messages SET status='read' WHERE conv_id=? AND mine=1", arrayOf(convId))

    // Groups
    fun saveGroup(id: String, name: String, members: List<String>) {
        val cv = ContentValues().apply { put("id",id);put("name",name);put("members",members.joinToString(",")) }
        writableDatabase.insertWithOnConflict("groups", null, cv, SQLiteDatabase.CONFLICT_REPLACE)
    }
    fun groups(): List<Group> {
        val list = mutableListOf<Group>()
        readableDatabase.rawQuery("SELECT id,name,members FROM groups", null).use { c ->
            while (c.moveToNext()) list.add(Group(c.getString(0), c.getString(1), c.getString(2).split(",")))
        }
        return list
    }
    data class CallRecord(val id: Long, val peerId: String, val peerName: String, val type: String, val duration: Int, val startedAt: Long)
    fun logCallStart(peerId: String, peerName: String, type: String): Long {
        val cv = ContentValues().apply { put("peer_id",peerId);put("peer_name",peerName);put("type",type);put("started_at",System.currentTimeMillis()) }
        return writableDatabase.insert("calls", null, cv)
    }
    fun logCallEnd(callId: Long, durationSec: Int) = writableDatabase.execSQL("UPDATE calls SET duration=? WHERE id=?", arrayOf(durationSec, callId))
    fun calls(limit: Int = 100): List<CallRecord> {
        val list = mutableListOf<CallRecord>()
        readableDatabase.rawQuery("SELECT id,peer_id,peer_name,type,duration,started_at FROM calls ORDER BY started_at DESC LIMIT ?", arrayOf(limit.toString())).use { c ->
            while (c.moveToNext()) list.add(CallRecord(c.getLong(0),c.getString(1),c.getString(2),c.getString(3),c.getInt(4),c.getLong(5)))
        }
        return list
    }

    fun group(id: String): Group? {
        readableDatabase.rawQuery("SELECT id,name,members FROM groups WHERE id=?", arrayOf(id)).use { c ->
            if (c.moveToFirst()) return Group(c.getString(0), c.getString(1), c.getString(2).split(","))
        }
        return null
    }
}
