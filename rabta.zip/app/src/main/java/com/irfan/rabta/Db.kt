package com.irfan.rabta

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper

/**
 * Local SQLite: conversations + messages.
 * All reads/writes happen on background threads (caller's responsibility).
 */
class Db(ctx: Context) : SQLiteOpenHelper(ctx, "rabta.db", null, 3) {

    data class Conversation(val peerId: String, val peerName: String, val lastMsg: String, val lastTime: Long, val unread: Int)
    data class Message(val id: String, val convId: String, val fromId: String, val body: String, val sentAt: Long, val mine: Boolean, val status: String, val type: String)

    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL("CREATE TABLE IF NOT EXISTS conversations(peer_id TEXT PRIMARY KEY, peer_name TEXT, last_msg TEXT, last_time INTEGER DEFAULT 0, unread INTEGER DEFAULT 0)")
        db.execSQL("CREATE TABLE IF NOT EXISTS messages(id TEXT PRIMARY KEY, conv_id TEXT, from_id TEXT, body TEXT, sent_at INTEGER, mine INTEGER DEFAULT 0, status TEXT DEFAULT 'sent', type TEXT DEFAULT 'text')")
        db.execSQL("CREATE INDEX IF NOT EXISTS idx_msg_conv ON messages(conv_id, sent_at)")
    }
    override fun onUpgrade(db: SQLiteDatabase, o: Int, n: Int) {
        db.execSQL("DROP TABLE IF EXISTS conversations")
        db.execSQL("DROP TABLE IF EXISTS messages")
        onCreate(db)
    }

    companion object {
        @Volatile private var INST: Db? = null
        fun get(ctx: Context) = INST ?: synchronized(this) { INST ?: Db(ctx.applicationContext).also { INST = it } }
    }

    fun upsertConversation(peerId: String, peerName: String, lastMsg: String, time: Long, incUnread: Boolean) {
        val cv = ContentValues().apply {
            put("peer_id", peerId); put("peer_name", peerName)
            put("last_msg", lastMsg.take(80)); put("last_time", time)
        }
        writableDatabase.insertWithOnConflict("conversations", null, cv, SQLiteDatabase.CONFLICT_IGNORE)
        writableDatabase.execSQL("UPDATE conversations SET peer_name=?,last_msg=?,last_time=?,unread=unread+? WHERE peer_id=?",
            arrayOf(peerName, lastMsg.take(80), time, if (incUnread) 1 else 0, peerId))
    }

    fun clearUnread(peerId: String) { writableDatabase.execSQL("UPDATE conversations SET unread=0 WHERE peer_id=?", arrayOf(peerId)) }

    fun conversations(): List<Conversation> {
        val list = mutableListOf<Conversation>()
        readableDatabase.rawQuery("SELECT peer_id,peer_name,last_msg,last_time,unread FROM conversations ORDER BY last_time DESC", null).use { c ->
            while (c.moveToNext()) list.add(Conversation(c.getString(0), c.getString(1), c.getString(2) ?: "", c.getLong(3), c.getInt(4)))
        }
        return list
    }

    fun saveMessage(id: String, convId: String, fromId: String, body: String, sentAt: Long, mine: Boolean, status: String = "sent", type: String = "text") {
        val cv = ContentValues().apply {
            put("id", id); put("conv_id", convId); put("from_id", fromId)
            put("body", body); put("sent_at", sentAt); put("mine", if (mine) 1 else 0)
            put("status", status); put("type", type)
        }
        writableDatabase.insertWithOnConflict("messages", null, cv, SQLiteDatabase.CONFLICT_IGNORE)
    }

    fun messages(convId: String, limit: Int = 200): List<Message> {
        val list = mutableListOf<Message>()
        readableDatabase.rawQuery("SELECT id,conv_id,from_id,body,sent_at,mine,status,type FROM messages WHERE conv_id=? ORDER BY sent_at ASC LIMIT ?",
            arrayOf(convId, limit.toString())).use { c ->
            while (c.moveToNext()) list.add(Message(c.getString(0), c.getString(1), c.getString(2), c.getString(3), c.getLong(4), c.getInt(5) == 1, c.getString(6), c.getString(7)))
        }
        return list
    }

    fun updateStatus(msgId: String, status: String) { writableDatabase.execSQL("UPDATE messages SET status=? WHERE id=?", arrayOf(status, msgId)) }
}
