package com.irfan.rabta

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.text.InputType
import android.view.Gravity
import android.view.ViewGroup
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import org.json.JSONObject

class AuthActivity : Activity() {

    private lateinit var serverInput: EditText
    private lateinit var usernameInput: EditText
    private lateinit var pinInput: EditText
    private lateinit var statusText: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Session.init(this)
        if (Session.loggedIn) { goMain(); return }
        buildUi()
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun round(c: Int, r: Int) = GradientDrawable().apply {
        setColor(c); cornerRadius = dp(r).toFloat()
    }

    private fun buildUi() {
        val BG   = 0xFF111B21.toInt()
        val CARD = 0xFF1F2C34.toInt()
        val G    = 0xFF25D366.toInt()
        val TXT  = 0xFFE9EDEF.toInt()
        val SUB  = 0xFF8696A0.toInt()
        val FLD  = 0xFF2A3942.toInt()

        val scroll = ScrollView(this).apply { setBackgroundColor(BG) }
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(24), dp(48), dp(24), dp(32))
        }
        scroll.addView(col)
        setContentView(scroll)

        fun lp(top: Int = 0, bot: Int = 0) = LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
        ).apply { topMargin = dp(top); bottomMargin = dp(bot) }

        fun field(hint: String, numeric: Boolean = false) = EditText(this).apply {
            this.hint = hint; textSize = 16f
            setTextColor(TXT); setHintTextColor(SUB); setSingleLine(true)
            background = round(FLD, 14); setPadding(dp(16), dp(14), dp(16), dp(14))
            inputType = if (numeric) InputType.TYPE_CLASS_NUMBER
                        else InputType.TYPE_CLASS_TEXT
        }

        fun label(t: String) = TextView(this).apply {
            text = t; textSize = 13f; setTextColor(SUB)
            typeface = Typeface.DEFAULT_BOLD; setPadding(dp(2), 0, 0, 0)
        }

        fun bigBtn(t: String, bg: Int, tc: Int, action: () -> Unit) = TextView(this).apply {
            text = t; textSize = 17f; typeface = Typeface.DEFAULT_BOLD
            setTextColor(tc); gravity = Gravity.CENTER
            background = round(bg, 28)
            setPadding(0, dp(16), 0, dp(16))
            isClickable = true; isFocusable = true
            setOnClickListener { action() }
        }

        // Header
        col.addView(TextView(this).apply {
            text = "Rabta"; textSize = 40f; setTextColor(G)
            typeface = Typeface.DEFAULT_BOLD; gravity = Gravity.CENTER
        })
        col.addView(TextView(this).apply {
            text = "رابطہ"; textSize = 22f; setTextColor(SUB); gravity = Gravity.CENTER
        })
        col.addView(TextView(this).apply {
            text = "Offline + Online chat"; textSize = 14f
            setTextColor(SUB); gravity = Gravity.CENTER
            setPadding(0, 0, 0, dp(32))
        })

        // Fields
        col.addView(label("Server URL"), lp(bot = 6))
        serverInput = field("https://rabta-server-xxxx.onrender.com")
        serverInput.setText(Session.serverUrl)
        col.addView(serverInput, lp(bot = 18))

        col.addView(label("Username"), lp(bot = 6))
        usernameInput = field("3-20 letters/numbers (e.g. irfan347)")
        col.addView(usernameInput, lp(bot = 18))

        col.addView(label("PIN"), lp(bot = 6))
        pinInput = field("4-8 numbers (e.g. 1425)", numeric = true)
        col.addView(pinInput, lp(bot = 10))

        // Status
        statusText = TextView(this).apply {
            textSize = 14f; setTextColor(SUB); gravity = Gravity.CENTER
        }
        col.addView(statusText, lp(top = 4, bot = 8))

        // Buttons - two clear separate ones
        col.addView(bigBtn("Naya account banayein", G, Color.BLACK) { doRegister() }, lp(bot = 12))
        col.addView(bigBtn("Pehle se account hai — Login karein", CARD, G) { doLogin() })

        col.addView(TextView(this).apply {
            text = "\nServer URL: Render par apni rabta-server service ka onrender.com link"
            textSize = 12f; setTextColor(0xFF445566.toInt()); gravity = Gravity.CENTER
            setPadding(0, dp(16), 0, 0)
        })
    }

    private fun validate(): Boolean {
        val server   = serverInput.text.toString().trim()
        val username = usernameInput.text.toString().trim()
        val pin      = pinInput.text.toString().trim()
        if (!server.startsWith("http")) { show("Server URL https:// se shuru hona chahiye"); return false }
        if (username.length < 3)         { show("Username kam az kam 3 characters ka hona chahiye"); return false }
        if (!username.matches(Regex("[a-zA-Z0-9_]+"))) { show("Username mein sirf letters aur numbers hone chahiye"); return false }
        if (pin.length < 4)              { show("PIN 4-8 numbers ka hona chahiye"); return false }
        return true
    }

    private fun doRegister() {
        if (!validate()) return
        val server   = serverInput.text.toString().trim().trimEnd('/')
        val username = usernameInput.text.toString().trim().lowercase()
        val pin      = pinInput.text.toString().trim()
        show("Account ban raha hai... (30-60 sec lag sakte hain)")
        Session.serverUrl = server
        WsClient.register(this, server, username, pin, username) { ok, msg, data ->
            if (ok && data != null) saveAndGo(data, server)
            else show("Error: $msg")
        }
    }

    private fun doLogin() {
        if (!validate()) return
        val server   = serverInput.text.toString().trim().trimEnd('/')
        val username = usernameInput.text.toString().trim().lowercase()
        val pin      = pinInput.text.toString().trim()
        show("Login ho raha hai... (30-60 sec lag sakte hain)")
        Session.serverUrl = server
        WsClient.login(this, server, username, pin) { ok, msg, data ->
            if (ok && data != null) saveAndGo(data, server)
            else show("Error: $msg")
        }
    }

    private fun show(s: String) { statusText.text = s }

    private fun saveAndGo(data: JSONObject, server: String) {
        Session.id        = data.optString("id")
        Session.username  = data.optString("username")
        Session.name      = data.optString("name").ifEmpty { data.optString("username") }
        Session.token     = data.optString("token")
        Session.serverUrl = server
        goMain()
    }

    private fun goMain() {
        startActivity(Intent(this, ConversationListActivity::class.java))
        finish()
    }
}
