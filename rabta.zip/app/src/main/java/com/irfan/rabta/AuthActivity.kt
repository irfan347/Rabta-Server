package com.irfan.rabta

import android.app.Activity
import android.content.Intent
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.text.InputType
import android.view.Gravity
import android.view.ViewGroup
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import org.json.JSONObject

class AuthActivity : Activity() {

    private lateinit var serverInput: EditText
    private lateinit var usernameInput: EditText
    private lateinit var pinInput: EditText
    private lateinit var nameInput: EditText
    private lateinit var statusText: TextView
    private var isRegister = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Session.init(this)
        if (Session.loggedIn) { goMain(); return }
        buildUi()
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun round(c: Int, r: Int) = GradientDrawable().apply { setColor(c); cornerRadius = dp(r).toFloat() }
    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()

    private fun buildUi() {
        val bg = 0xFF111B21.toInt()
        val card = 0xFF1F2C34.toInt()
        val green = 0xFF25D366.toInt()
        val txt = 0xFFE9EDEF.toInt()
        val sub = 0xFF8696A0.toInt()
        val fieldBg = 0xFF2A3942.toInt()

        val scroll = ScrollView(this).apply { setBackgroundColor(bg) }
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(24), dp(40), dp(24), dp(32)) }
        scroll.addView(col)
        setContentView(scroll)

        col.addView(TextView(this).apply { text = "Rabta"; textSize = 36f; setTextColor(green); typeface = Typeface.DEFAULT_BOLD; gravity = Gravity.CENTER })
        col.addView(TextView(this).apply { text = "رابطہ"; textSize = 22f; setTextColor(sub); gravity = Gravity.CENTER; setPadding(0, 0, 0, dp(8)) })
        col.addView(TextView(this).apply { text = "Secure chat - online aur offline"; textSize = 15f; setTextColor(sub); gravity = Gravity.CENTER; setPadding(0, 0, 0, dp(32)) })

        fun field(hint: String, pass: Boolean = false, number: Boolean = false): EditText {
            return EditText(this).apply {
                this.hint = hint; textSize = 16f; setTextColor(txt); setHintTextColor(sub); setSingleLine(true)
                background = round(fieldBg, 12); setPadding(dp(16), dp(14), dp(16), dp(14))
                inputType = when { pass -> InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD; number -> InputType.TYPE_CLASS_NUMBER; else -> InputType.TYPE_CLASS_TEXT }
            }
        }
        fun lp(top: Int = 0, bottom: Int = 0) = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = dp(top); bottomMargin = dp(bottom) }
        fun btn(label: String, color: Int, onClick: () -> Unit) = TextView(this).apply {
            text = label; textSize = 16f; typeface = Typeface.DEFAULT_BOLD; setTextColor(0xFF111B21.toInt())
            gravity = Gravity.CENTER; background = round(color, 28); setPadding(0, dp(15), 0, dp(15))
            isClickable = true; setOnClickListener { onClick() }
        }

        serverInput = field("Server URL (https://...)")
        usernameInput = field("Username (3-20 letters/numbers)")
        pinInput = field("PIN (4-8 digits)", number = true)
        nameInput = field("Display name (e.g. Irfan Ali)")
        statusText = TextView(this).apply { textSize = 14f; setTextColor(sub); gravity = Gravity.CENTER }

        col.addView(TextView(this).apply { text = "Server URL"; textSize = 13f; setTextColor(sub); typeface = Typeface.DEFAULT_BOLD })
        col.addView(serverInput, lp(top = 6, bottom = 20))
        col.addView(TextView(this).apply { text = "Username"; textSize = 13f; setTextColor(sub); typeface = Typeface.DEFAULT_BOLD })
        col.addView(usernameInput, lp(top = 6))
        col.addView(TextField("PIN (4-8 numbers)", sub).also {}, lp(top = 14))
        col.addView(pinInput, lp(top = 6))
        nameInput.visibility = android.view.View.GONE
        col.addView(nameInput, lp(top = 14))
        col.addView(statusText, lp(top = 10, bottom = 6))
        col.addView(btn("Log in", green) { doLogin() }, lp(top = 8))
        col.addView(btn("Server test karein", 0xFF2A3942.toInt()) { testServer() }.also { it.setTextColor(0xFF8696A0.toInt()) }, lp(top = 8))
        col.addView(btn("Register (naya account)", 0xFF2A3942.toInt()) { toggleRegister() }.also { it.setTextColor(green) }, lp(top = 12))

        // Pre-fill if previously used
        serverInput.setText(Session.serverUrl)
    }

    private inner class TextField(hint: String, color: Int) : TextView(this) {
        init { text = hint; textSize = 13f; setTextColor(color); typeface = Typeface.DEFAULT_BOLD }
    }

    private fun toggleRegister() {
        isRegister = !isRegister
        nameInput.visibility = if (isRegister) android.view.View.VISIBLE else android.view.View.GONE
        statusText.text = if (isRegister) "Naya account banaiye" else ""
    }

    private fun doLogin() {
        val server = serverInput.text.toString().trim().trimEnd('/')
        val username = usernameInput.text.toString().trim().lowercase()
        val pin = pinInput.text.toString().trim()
        val name = nameInput.text.toString().trim().ifEmpty { username }
        if (server.isEmpty()) { statusText.text = "Server URL daalen"; return }
        if (username.isEmpty() || pin.isEmpty()) { statusText.text = "Username aur PIN zaroori hai"; return }
        statusText.text = if (isRegister) "Account bana raha hoon..." else "Login ho raha hoon..."

        Session.serverUrl = server
        if (isRegister) {
            WsClient.register(this, server, username, pin, name) { ok, msg, data ->
                if (ok && data != null) { saveAndGo(data, server) } else { statusText.text = msg }
            }
        } else {
            WsClient.login(this, server, username, pin) { ok, msg, data ->
                if (ok && data != null) { saveAndGo(data, server) } else { statusText.text = msg }
            }
        }
    }

    private fun saveAndGo(data: JSONObject, server: String) {
        Session.id = data.optString("id")
        Session.username = data.optString("username")
        Session.name = data.optString("name").ifEmpty { data.optString("username") }
        Session.token = data.optString("token")
        Session.serverUrl = server
        goMain()
    }

    private fun testServer() {
        val url = serverInput.text.toString().trim().trimEnd('/')
        if (url.isEmpty()) { statusText.text = "Pehle server URL daalen"; return }
        statusText.text = "Server check ho raha hai..."
        WsClient.register(this, url, "testuser_check_delete", "123456", "test") { ok, msg, _ ->
            statusText.text = if (ok || msg.contains("already") || msg.contains("taken")) {
                "Server chal raha hai ✓ Ab register ya login karein"
            } else if (msg.contains("so gaya") || msg.contains("timeout")) {
                "Server so gaya tha - ab uth raha hai. 30 sec mein dobara login karein"
            } else {
                "Server problem: $msg"
            }
        }
    }

    private fun goMain() { startActivity(Intent(this, ConversationListActivity::class.java)); finish() }
}

