package com.irfan.rabta

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import org.json.JSONObject

class AuthActivity : Activity() {

    private lateinit var usernameField: EditText
    private lateinit var pinField: EditText
    private lateinit var statusText: TextView
    private lateinit var loginBtn: TextView
    private lateinit var registerBtn: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Session.init(this)
        if (Session.loggedIn) { goHome(); return }
        buildUi()
    }

    private fun dp(n: Int) = (n * resources.displayMetrics.density).toInt()

    private fun pill(c: Int, r: Int = 999) = GradientDrawable().apply {
        setColor(c); cornerRadius = dp(r).toFloat()
    }

    private fun buildUi() {
        // Full green top half, white bottom
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        setContentView(root)

        // ---- TOP (green) ----
        val top = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setBackgroundColor(0xFF128C7E.toInt())
            setPadding(dp(32), dp(60), dp(32), dp(40))
        }
        top.addView(TextView(this).apply {
            text = "Rabta"; textSize = 42f; typeface = Typeface.DEFAULT_BOLD
            setTextColor(Color.WHITE); gravity = Gravity.CENTER
        })
        top.addView(TextView(this).apply {
            text = "رابطہ"; textSize = 20f; setTextColor(0xCCFFFFFF.toInt()); gravity = Gravity.CENTER
        })
        top.addView(TextView(this).apply {
            text = "Offline + online chat"; textSize = 14f
            setTextColor(0xAAFFFFFF.toInt()); gravity = Gravity.CENTER
            setPadding(0, dp(8), 0, 0)
        })
        root.addView(top)

        // ---- BOTTOM (white card) ----
        val bot = ScrollView(this).apply { setBackgroundColor(Color.WHITE) }
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(28), dp(28), dp(28), dp(28))
        }
        bot.addView(col)
        root.addView(bot, LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))

        fun label(t: String) = TextView(this).apply {
            text = t; textSize = 13f; setTextColor(0xFF128C7E.toInt())
            typeface = Typeface.DEFAULT_BOLD; setPadding(dp(4), 0, 0, dp(4))
        }
        fun field(hint: String, pwd: Boolean = false) = EditText(this).apply {
            this.hint = hint; textSize = 16f
            setTextColor(0xFF1A1A1A.toInt()); setHintTextColor(0xFFAAAAAA.toInt())
            setSingleLine(true); background = null
            setPadding(dp(12), dp(14), dp(12), dp(14))
            inputType = if (pwd) InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_VARIATION_PASSWORD
                        else InputType.TYPE_CLASS_TEXT
        }
        fun divider() = View(this).apply {
            setBackgroundColor(0xFFE0E0E0.toInt())
        }.also { col.addView(it, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(1))) }
        fun lp(t: Int = 0, b: Int = 0) = LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
        ).apply { topMargin = dp(t); bottomMargin = dp(b) }

        // Username
        col.addView(label("Username"), lp(b = 2))
        usernameField = field("e.g. irfan347"); col.addView(usernameField)
        divider()

        // PIN
        col.addView(label("PIN"), lp(t = 18, b = 2))
        pinField = field("4-8 numbers", pwd = true); col.addView(pinField)
        divider()

        // Status
        statusText = TextView(this).apply {
            textSize = 13f; setTextColor(0xFFD32F2F.toInt()); gravity = Gravity.CENTER
        }
        col.addView(statusText, lp(t = 14, b = 4))

        // Buttons
        loginBtn = bigBtn("LOGIN", 0xFF128C7E.toInt()) { doLogin() }
        registerBtn = bigBtn("SIGN UP", Color.WHITE, outline = true) { doRegister() }
        col.addView(loginBtn, lp(t = 16, b = 10))
        col.addView(registerBtn)

        col.addView(TextView(this).apply {
            text = "Pakistan ka pehla offline + online chat app"
            textSize = 12f; setTextColor(0xFFAAAAAA.toInt()); gravity = Gravity.CENTER
            setPadding(0, dp(24), 0, 0)
        })
    }

    private fun bigBtn(text: String, bg: Int, outline: Boolean = false, onClick: () -> Unit) =
        TextView(this).apply {
            this.text = text; textSize = 15f; typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER; setPadding(0, dp(16), 0, dp(16))
            setTextColor(if (outline) 0xFF128C7E.toInt() else Color.WHITE)
            background = if (outline) GradientDrawable().apply {
                setColor(Color.WHITE); cornerRadius = dp(28).toFloat()
                setStroke(dp(2), 0xFF128C7E.toInt())
            } else pill(bg, 28)
            isClickable = true; isFocusable = true
            setOnClickListener { onClick() }
        }

    private fun validate(): Boolean {
        val u = usernameField.text.toString().trim()
        val p = pinField.text.toString().trim()
        return when {
            u.length < 3  -> { statusText.text = "Username 3+ characters hona chahiye"; false }
            !u.matches(Regex("[a-zA-Z0-9_]+")) -> { statusText.text = "Sirf letters, numbers aur _"; false }
            p.length < 4  -> { statusText.text = "PIN 4-8 numbers ka hona chahiye"; false }
            else -> true
        }
    }

    private fun setLoading(on: Boolean) {
        loginBtn.isClickable = !on; registerBtn.isClickable = !on
        loginBtn.alpha = if (on) 0.5f else 1f; registerBtn.alpha = if (on) 0.5f else 1f
    }

    private fun doLogin() {
        if (!validate()) return
        statusText.text = "Login ho raha hai..."; statusText.setTextColor(0xFF128C7E.toInt()); setLoading(true)
        WsClient.login(this, Config.SERVER, usernameField.text.toString().trim().lowercase(), pinField.text.toString().trim()) { ok, msg, data ->
            setLoading(false)
            if (ok && data != null) saveAndGo(data) else { statusText.text = msg; statusText.setTextColor(0xFFD32F2F.toInt()) }
        }
    }

    private fun doRegister() {
        if (!validate()) return
        val un = usernameField.text.toString().trim().lowercase()
        statusText.text = "Account ban raha hai..."; statusText.setTextColor(0xFF128C7E.toInt()); setLoading(true)
        WsClient.register(this, Config.SERVER, un, pinField.text.toString().trim(), un) { ok, msg, data ->
            setLoading(false)
            if (ok && data != null) saveAndGo(data) else { statusText.text = msg; statusText.setTextColor(0xFFD32F2F.toInt()) }
        }
    }

    private fun saveAndGo(data: JSONObject) {
        Session.id = data.optString("id"); Session.username = data.optString("username")
        Session.name = data.optString("name").ifEmpty { data.optString("username") }
        Session.token = data.optString("token"); Session.serverUrl = Config.SERVER
        goHome()
    }

    private fun goHome() { startActivity(Intent(this, ConversationListActivity::class.java)); finish() }
}
