package com.irfan.rabta

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import org.json.JSONObject
import java.security.SecureRandom
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class ChatActivity : Activity(), RabtaEvents.Listener {

    companion object { @Volatile var openPeer: String? = null }

    private val G    = 0xFF25D366.toInt()
    private val BG   = 0xFF0B141A.toInt()
    private val CARD = 0xFF1F2C34.toInt()
    private val SUB  = 0xFF8696A0.toInt()
    private val TXT  = 0xFFE9EDEF.toInt()
    private val SENT = 0xFF005C4B.toInt()
    private val RECV = 0xFF1F2C34.toInt()
    private val RED  = 0xFFD93025.toInt()

    private lateinit var peerId: String
    private lateinit var peerName: String
    private lateinit var chatBox: LinearLayout
    private lateinit var chatScroll: ScrollView
    private lateinit var input: EditText
    private lateinit var statusTv: TextView
    private lateinit var callOverlay: LinearLayout
    private lateinit var callStatusTv: TextView
    private val handler = Handler(Looper.getMainLooper())
    private lateinit var db: Db

    // Calls
    private var netCall: InternetVoiceCall? = null
    private var inCall = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Session.init(this)
        peerId   = intent.getStringExtra("peerId")   ?: ""
        peerName = intent.getStringExtra("peerName") ?: "User"
        if (peerId.isEmpty()) { finish(); return }
        db = Db.get(this)
        buildUi()
        RabtaEvents.add(this)
        loadHistory()
        if (intent.getBooleanExtra("autoAnswer", false)) handler.post { startVoiceCall(initiate = false) }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        if (intent.getBooleanExtra("autoAnswer", false) && intent.getStringExtra("peerId") == peerId) {
            startVoiceCall(initiate = false)
        }
    }

    override fun onPause() { super.onPause(); openPeer = null }
    override fun onResume()  { super.onResume();  openPeer = peerId; RabtaEvents.add(this); handler.post { updateStatus() } }
    override fun onDestroy() {
        endCall(); RabtaEvents.remove(this)
        Thread { try { db.clearUnread(peerId) } catch (_: Exception) {} }.start()
        super.onDestroy()
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun round(c: Int, r: Int) = GradientDrawable().apply { setColor(c); cornerRadius = dp(r).toFloat() }
    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()
    private fun fmtTime(t: Long) = SimpleDateFormat("HH:mm", Locale.getDefault()).format(Date(t))

    private fun avatar(name: String, sz: Int) = TextView(this).apply {
        val cols = listOf(0xFF2196F3, 0xFF9C27B0, 0xFFE91E63, 0xFF009688)
        text = name.filter { it.isLetterOrDigit() }.take(1).uppercase().ifEmpty { "?" }
        textSize = sz * 0.38f; typeface = Typeface.DEFAULT_BOLD; setTextColor(Color.WHITE); gravity = Gravity.CENTER
        background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(cols[(name.hashCode() and 0x7FFFFFFF) % cols.size].toInt()) }
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(BG) }
        setContentView(root)

        // Header
        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
            setBackgroundColor(CARD); setPadding(dp(8), dp(10), dp(12), dp(10))
        }
        header.addView(TextView(this).apply {
            text = "←"; textSize = 22f; setTextColor(TXT)
            setPadding(dp(8), dp(4), dp(14), dp(4)); isClickable = true
            setOnClickListener { finish() }
        })
        header.addView(avatar(peerName, dp(40)), LinearLayout.LayoutParams(dp(40), dp(40)))
        val hCol = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(10), 0, 0, 0) }
        TextView(this).apply { text = peerName; textSize = 17f; setTextColor(TXT); typeface = Typeface.DEFAULT_BOLD }.also { hCol.addView(it) }
        statusTv = TextView(this).apply { textSize = 12f; setTextColor(SUB) }.also { hCol.addView(it) }
        header.addView(hCol, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))

        // Call buttons
        header.addView(callIconBtn("📞") { startVoiceCall(initiate = true) })
        header.addView(callIconBtn("🎥") { startVideoCall() })
        root.addView(header)

        // Call overlay (hidden by default)
        callOverlay = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER
            setBackgroundColor(0xFF0D1F1A.toInt()); visibility = View.GONE
            setPadding(dp(32), dp(60), dp(32), dp(60))
        }
        callOverlay.addView(avatar(peerName, dp(80)), LinearLayout.LayoutParams(dp(80), dp(80)).apply { gravity = Gravity.CENTER })
        callOverlay.addView(TextView(this).apply {
            text = peerName; textSize = 26f; typeface = Typeface.DEFAULT_BOLD
            setTextColor(TXT); gravity = Gravity.CENTER; setPadding(0, dp(16), 0, dp(8))
        })
        callStatusTv = TextView(this).apply { textSize = 16f; setTextColor(SUB); gravity = Gravity.CENTER }
        callOverlay.addView(callStatusTv)
        val endBtn = LinearLayout(this).apply { gravity = Gravity.CENTER; setPadding(0, dp(50), 0, 0) }
        endBtn.addView(TextView(this).apply {
            text = "📵"; textSize = 36f; gravity = Gravity.CENTER
            background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(RED) }
            setPadding(dp(20), dp(20), dp(20), dp(20))
            isClickable = true; setOnClickListener { endCall() }
        }, LinearLayout.LayoutParams(dp(80), dp(80)))
        callOverlay.addView(endBtn)
        root.addView(callOverlay)

        // Messages
        chatScroll = ScrollView(this).apply { setBackgroundColor(BG) }
        chatBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(8), dp(8), dp(8), dp(8)) }
        chatScroll.addView(chatBox)
        root.addView(chatScroll, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))

        // Input bar
        val bar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.BOTTOM
            setBackgroundColor(CARD); setPadding(dp(8), dp(8), dp(8), dp(8))
        }
        input = EditText(this).apply {
            hint = "Message"; textSize = 16f; setTextColor(TXT); setHintTextColor(SUB); maxLines = 5
            background = round(0xFF2A3942.toInt(), 24); setPadding(dp(16), dp(10), dp(16), dp(10))
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE or InputType.TYPE_TEXT_FLAG_CAP_SENTENCES
        }
        bar.addView(input, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply { marginEnd = dp(8) })
        bar.addView(TextView(this).apply {
            text = "↑"; textSize = 22f; setTextColor(Color.WHITE); gravity = Gravity.CENTER
            background = round(G, 24); isClickable = true; setOnClickListener { sendMsg() }
        }, LinearLayout.LayoutParams(dp(48), dp(48)))
        root.addView(bar)
    }

    private fun callIconBtn(icon: String, onClick: () -> Unit) = TextView(this).apply {
        text = icon; textSize = 22f; gravity = Gravity.CENTER
        setPadding(dp(8), dp(4), dp(8), dp(4)); isClickable = true; setOnClickListener { onClick() }
    }

    // ---------- Voice call ----------
    private var pendingInitiate = true

    private fun startVoiceCall(initiate: Boolean) {
        if (inCall) return
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            pendingInitiate = initiate
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.RECORD_AUDIO), 99)
            return
        }
        if (!WsClient.connected) { toast("Call ke liye internet chahiye"); return }
        inCall = true
        callOverlay.visibility = View.VISIBLE
        netCall = InternetVoiceCall(peerId) { msg -> handler.post { callStatusTv.text = msg } }
        netCall?.start(initiate)
    }

    private fun startVideoCall() {
        toast("Video call — agle update mein aayegi! Abhi voice call use karein 📞")
    }

    private fun endCall(sendEnd: Boolean = true) {
        if (!inCall) return
        inCall = false
        netCall?.stop(sendEnd); netCall = null
        handler.post { callOverlay.visibility = View.GONE }
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, results: IntArray) {
        if (requestCode == 99 && results.isNotEmpty() && results[0] == PackageManager.PERMISSION_GRANTED) startVoiceCall(pendingInitiate)
        else toast("Mic permission chahiye call ke liye")
    }

    // ---------- Chat ----------
    private fun loadHistory() {
        Thread {
            try {
                val msgs = db.messages(peerId)
                db.clearUnread(peerId)
                handler.post {
                    chatBox.removeAllViews()
                    msgs.forEach { m -> addBubble(m.body, m.mine, fmtTime(m.sentAt), m.status) }
                    scrollToBottom()
                }
            } catch (e: Exception) {
                handler.post { statusTv.text = "Load error: ${e.message}" }
            }
        }.start()
    }

    private fun addBubble(text: String, mine: Boolean, time: String, status: String = "sent") {
        val wrap = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = if (mine) Gravity.END else Gravity.START
        }
        val bubble = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = round(if (mine) SENT else RECV, 12)
            setPadding(dp(12), dp(8), dp(12), dp(8))
        }
        TextView(this).also { tv ->
            tv.text = text; tv.textSize = 15f; tv.setTextColor(TXT); tv.setLineSpacing(0f, 1.2f)
            bubble.addView(tv)
        }
        val foot = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.END or Gravity.BOTTOM; setPadding(dp(8), dp(2), 0, 0)
        }
        foot.addView(TextView(this).apply { this.text = time; textSize = 11f; setTextColor(SUB) })
        if (mine) foot.addView(TextView(this).apply {
            this.text = when (status) { "delivered" -> " ✓✓"; "read" -> " ✓✓"; else -> " ✓" }
            textSize = 11f; setTextColor(if (status == "read") G else SUB)
        })
        bubble.addView(foot)
        wrap.addView(bubble, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT)
            .apply { topMargin = dp(2); bottomMargin = dp(2); if (mine) marginStart = dp(60) else marginEnd = dp(60) })
        chatBox.addView(wrap, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
    }

    private fun scrollToBottom() { handler.post { chatScroll.fullScroll(View.FOCUS_DOWN) } }

    private fun sendMsg() {
        val text = input.text.toString().trim(); if (text.isEmpty()) return
        val msgId = ByteArray(8).also { SecureRandom().nextBytes(it) }.joinToString("") { "%02X".format(it) }
        val t = System.currentTimeMillis()
        input.setText("")
        val sentOk = WsClient.send(peerId, msgId, text)
        addBubble(text, true, fmtTime(t), "sent"); scrollToBottom()
        Thread { db.saveMessage(msgId, peerId, Session.id, text, t, true, if (sentOk) "sent" else "mesh"); db.upsertConversation(peerId, peerName, text, t, false) }.start()
        if (!sentOk) MeshBridge.sendText(peerId, peerName, msgId, text)
    }

    private fun updateStatus() { statusTv.text = if (WsClient.connected) "Online ✓" else "Offline" }

    // RabtaEvents.Listener
    override fun onConnected()    { handler.post { updateStatus() } }
    override fun onDisconnected() { handler.post { updateStatus() } }
    override fun onMessage(fromId: String, fromName: String, msgId: String, body: String, t: Long) {
        if (fromId != peerId) return
        Thread { db.saveMessage(msgId, peerId, fromId, body, t, false, "delivered") }.start()
        handler.post { addBubble(body, false, fmtTime(t)); scrollToBottom() }
    }
    override fun onAck(msgId: String, status: String) {
        Thread { db.updateStatus(msgId, status) }.start()
    }
    override fun onCallAudio(fromId: String, data: String) {
        if (fromId == peerId) netCall?.onAudio(data)
    }
    override fun onCallEnd(fromId: String) {
        if (fromId == peerId) handler.post { endCall(sendEnd = false); toast("Call khatam") }
    }
}
