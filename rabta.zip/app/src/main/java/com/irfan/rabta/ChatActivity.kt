package com.irfan.rabta

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.media.MediaPlayer
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.text.Editable
import android.text.InputType
import android.text.TextWatcher
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import java.security.SecureRandom
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class ChatActivity : Activity(), RabtaEvents.Listener {

    companion object { @Volatile var openPeer: String? = null }

    private val GREEN  = 0xFF128C7E.toInt()
    private val GREEN2 = 0xFF25D366.toInt()
    private val BEIGE  = 0xFFECE5DD.toInt()
    private val SENT   = 0xFFDCF8C6.toInt()
    private val RECV   = Color.WHITE
    private val TXT    = 0xFF1A1A1A.toInt()
    private val SUB    = 0xFF777777.toInt()
    private val RED    = 0xFFD32F2F.toInt()
    private val BLUE   = 0xFF1976D2.toInt()

    private lateinit var peerId: String
    private lateinit var peerName: String
    private var isGroup = false
    private lateinit var chatBox: LinearLayout
    private lateinit var chatScroll: ScrollView
    private lateinit var input: EditText
    private lateinit var sendBtn: TextView
    private lateinit var micBtn: TextView
    private lateinit var statusTv: TextView
    private lateinit var typingTv: TextView
    private lateinit var callOverlay: LinearLayout
    private lateinit var callStatusTv: TextView
    private val handler = Handler(Looper.getMainLooper())
    private lateinit var db: Db
    private var netCall: InternetVoiceCall? = null
    private var inCall = false
    private var pendingInitiate = true
    private val PICK_IMAGE = 101
    private var typingHideRunnable = Runnable { typingTv.visibility = View.GONE }
    private var sendTypingRunnable = Runnable { WsClient.sendTyping(peerId) }
    private var lastTypingSent = 0L

    private val statusTick = object : Runnable {
        override fun run() { updateStatus(); handler.postDelayed(this, 4000) }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Session.init(this)
        peerId   = intent.getStringExtra("peerId")   ?: ""
        peerName = intent.getStringExtra("peerName") ?: "User"
        isGroup  = intent.getBooleanExtra("isGroup", false)
        if (peerId.isEmpty()) { finish(); return }
        db = Db.get(this)
        buildUi()
        RabtaEvents.add(this)
        loadHistory()
        if (intent.getBooleanExtra("autoAnswer", false)) handler.post { startCall(false) }
    }

    override fun onResume() {
        super.onResume(); openPeer = peerId; handler.post(statusTick); RabtaEvents.add(this)
        // Send read receipts
        Thread { try { db.markAllRead(peerId) } catch (_: Exception) {} }.start()
        WsClient.sendRead(peerId, "all")
    }
    override fun onPause() { super.onPause(); openPeer = null; handler.removeCallbacks(statusTick) }
    override fun onDestroy() {
        endCall(); RabtaEvents.remove(this)
        Thread { try { db.clearUnread(peerId) } catch (_: Exception) {} }.start()
        super.onDestroy()
    }

    private fun dp(n: Int) = (n * resources.displayMetrics.density).toInt()
    private fun pill(c: Int) = GradientDrawable().apply { setColor(c); cornerRadius = dp(999).toFloat() }
    private fun rect(c: Int, r: Int) = GradientDrawable().apply { setColor(c); cornerRadius = dp(r).toFloat() }
    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()
    private fun fmtTime(t: Long) = SimpleDateFormat("HH:mm", Locale.getDefault()).format(Date(t))

    private fun avatarView(name: String, sz: Int): TextView {
        val cols = listOf(0xFFE53935, 0xFF9C27B0, 0xFF3F51B5, 0xFF009688, 0xFF43A047, 0xFFFF5722)
        return TextView(this).apply {
            text = name.filter { it.isLetterOrDigit() }.take(1).uppercase().ifEmpty { "?" }
            textSize = sz*0.38f; typeface = Typeface.DEFAULT_BOLD; setTextColor(Color.WHITE); gravity = Gravity.CENTER
            background = pill(cols[(name.hashCode() and 0x7FFFFFFF) % cols.size].toInt())
        }
    }

    private fun buildUi() {
        try { window.statusBarColor = 0xFF075E54.toInt() } catch (_: Exception) {}
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        setContentView(root)

        // Header
        val hdr = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setBackgroundColor(GREEN); setPadding(dp(4), dp(8), dp(10), dp(8)) }
        hdr.addView(TextView(this).apply { text = "←"; textSize = 22f; setTextColor(Color.WHITE); setPadding(dp(4),dp(4),dp(8),dp(4)); isClickable=true; setOnClickListener { finish() } })
        hdr.addView(avatarView(peerName, dp(40)), LinearLayout.LayoutParams(dp(40), dp(40)))
        val hdrCol = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(10),0,0,0) }
        hdrCol.addView(TextView(this).apply { text = peerName; textSize = 17f; typeface = Typeface.DEFAULT_BOLD; setTextColor(Color.WHITE) })
        val subRow = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        statusTv = TextView(this).apply { textSize = 12f; setTextColor(0xCCFFFFFF.toInt()) }
        typingTv = TextView(this).apply { textSize = 12f; setTextColor(0xCCFFFFFF.toInt()); text = "typing..."; visibility = View.GONE }
        subRow.addView(statusTv); subRow.addView(typingTv)
        hdrCol.addView(subRow)
        hdr.addView(hdrCol, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        if (!isGroup) hdr.addView(iconBtn("📞") { startCall(true) })
        hdr.addView(iconBtn("🎥") { startVideoCall() })
        root.addView(hdr)

        // Call overlay
        callOverlay = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER; setBackgroundColor(0xF00D1F1A.toInt()); visibility = View.GONE; setPadding(dp(32),dp(60),dp(32),dp(60)) }
        callOverlay.addView(avatarView(peerName, dp(80)), LinearLayout.LayoutParams(dp(80),dp(80)).apply { gravity = Gravity.CENTER })
        callOverlay.addView(TextView(this).apply { text = peerName; textSize = 26f; typeface = Typeface.DEFAULT_BOLD; setTextColor(Color.WHITE); gravity = Gravity.CENTER; setPadding(0,dp(16),0,dp(6)) })
        callStatusTv = TextView(this).apply { textSize = 16f; setTextColor(0xCCFFFFFF.toInt()); gravity = Gravity.CENTER }
        callOverlay.addView(callStatusTv)
        callOverlay.addView(LinearLayout(this).apply { gravity = Gravity.CENTER; setPadding(0,dp(50),0,0)
            addView(TextView(this@ChatActivity).apply { text = "📵"; textSize = 30f; gravity = Gravity.CENTER; background = pill(RED); setPadding(dp(22),dp(22),dp(22),dp(22)); isClickable=true; setOnClickListener { endCall() } }, LinearLayout.LayoutParams(dp(76),dp(76))) })
        root.addView(callOverlay)

        // Chat scroll
        chatScroll = ScrollView(this).apply { setBackgroundColor(BEIGE) }
        chatBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(10),dp(8),dp(10),dp(8)) }
        chatScroll.addView(chatBox)
        root.addView(chatScroll, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))

        // Input bar
        val bar = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.BOTTOM; setBackgroundColor(0xFFF0F0F0.toInt()); setPadding(dp(6),dp(6),dp(6),dp(6)) }
        // 📎 attach
        bar.addView(iconBtn("📎") { pickImage() }.apply { setPadding(dp(6),dp(4),dp(4),dp(4)) })
        // text input
        input = EditText(this).apply {
            hint = "Paigham..."; textSize = 16f; setTextColor(TXT); setHintTextColor(0xFFAAAAAA.toInt()); maxLines = 5
            background = rect(Color.WHITE, 24); setPadding(dp(14),dp(10),dp(14),dp(10))
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE or InputType.TYPE_TEXT_FLAG_CAP_SENTENCES
            addTextChangedListener(object : TextWatcher {
                override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
                override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {
                    val hasText = !s.isNullOrBlank()
                    sendBtn.visibility = if (hasText) View.VISIBLE else View.GONE
                    micBtn.visibility  = if (hasText) View.GONE else View.VISIBLE
                    // typing indicator
                    val now = System.currentTimeMillis()
                    if (hasText && now - lastTypingSent > 2500) {
                        lastTypingSent = now
                        handler.removeCallbacks(sendTypingRunnable)
                        handler.postDelayed(sendTypingRunnable, 300)
                    }
                }
                override fun afterTextChanged(s: Editable?) {}
            })
        }
        bar.addView(input, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply { marginStart = dp(4); marginEnd = dp(4) })
        // send button
        sendBtn = TextView(this).apply { text = "➤"; textSize = 20f; setTextColor(Color.WHITE); gravity = Gravity.CENTER; background = pill(GREEN2); isClickable = true; setOnClickListener { sendMsg() }; visibility = View.GONE }
        bar.addView(sendBtn, LinearLayout.LayoutParams(dp(46), dp(46)))
        // mic hold-to-record
        micBtn = TextView(this).apply {
            text = "🎤"; textSize = 22f; gravity = Gravity.CENTER; background = pill(GREEN2)
            setOnTouchListener { _, event ->
                when (event.action) {
                    MotionEvent.ACTION_DOWN -> { checkAudioPermission { startVoiceRecord() }; true }
                    MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> { stopVoiceRecord(send = event.action == MotionEvent.ACTION_UP); true }
                    else -> false
                }
            }
        }
        bar.addView(micBtn, LinearLayout.LayoutParams(dp(46), dp(46)))
        root.addView(bar)
    }

    private fun iconBtn(icon: String, onClick: () -> Unit) = TextView(this).apply {
        text = icon; textSize = 20f; gravity = Gravity.CENTER; setPadding(dp(8),dp(4),dp(8),dp(4)); isClickable=true; setOnClickListener { onClick() }
    }

    // ── History ──
    private fun loadHistory() {
        Thread {
            val msgs = try { db.messages(peerId) } catch (_: Exception) { emptyList() }
            try { db.clearUnread(peerId) } catch (_: Exception) {}
            handler.post {
                chatBox.removeAllViews()
                msgs.forEach { m -> addBubble(m.body, m.mine, fmtTime(m.sentAt), m.status, m.msgType, if (isGroup && !m.mine) m.fromName else "") }
                scrollBottom()
            }
        }.start()
    }

    // ── Bubbles ──
    private fun addBubble(body: String, mine: Boolean, time: String, status: String = "sent", msgType: String = "text", senderName: String = "") {
        val wrap = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = if (mine) Gravity.END else Gravity.START }
        val bubble = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = GradientDrawable().apply { setColor(if (mine) SENT else RECV); cornerRadius = dp(12).toFloat(); if (!mine) setStroke(dp(1), 0x11000000) }
            setPadding(dp(10),dp(8),dp(10),dp(5)); elevation = dp(1).toFloat()
        }
        // Group sender name
        if (senderName.isNotEmpty()) bubble.addView(TextView(this).apply {
            text = senderName; textSize = 13f; typeface = Typeface.DEFAULT_BOLD
            setTextColor(listOf(0xFFE53935,0xFF9C27B0,0xFF3F51B5,0xFF009688).let { it[(senderName.hashCode() and 0x7FFFFFFF)%it.size].toInt() })
        })
        when (msgType) {
            "image" -> {
                val bmp = MediaHelper.base64ToBitmap(body)
                if (bmp != null) {
                    val iv = ImageView(this).apply { setImageBitmap(bmp); scaleType = ImageView.ScaleType.CENTER_CROP; adjustViewBounds = true }
                    bubble.addView(iv, LinearLayout.LayoutParams(dp(200), dp(200)))
                } else bubble.addView(textLine("📷 Photo (load error)"))
            }
            "voice" -> {
                val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
                val play = TextView(this).apply {
                    text = "▶"; textSize = 18f; setTextColor(GREEN); setPadding(0,0,dp(8),0); isClickable = true
                    setOnClickListener { MediaHelper.playVoice(context, body)?.let { text = "⏹" } }
                }
                row.addView(play); row.addView(textLine("🎤 Voice note"))
                bubble.addView(row)
            }
            else -> bubble.addView(textLine(body))
        }
        // Footer: time + ticks
        val foot = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.END or Gravity.BOTTOM; setPadding(dp(4),dp(2),0,0) }
        foot.addView(TextView(this).apply { this.text = time; textSize = 11f; setTextColor(SUB) })
        if (mine) foot.addView(TextView(this).apply {
            this.text = when(status) { "delivered","read" -> " ✓✓"; "mesh" -> " 📡"; else -> " ✓" }
            textSize = 11f; setTextColor(if (status == "read") BLUE else if (status == "delivered") GREEN else SUB)
        })
        bubble.addView(foot)
        val maxW = (resources.displayMetrics.widthPixels * 0.78).toInt()
        wrap.addView(bubble, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
            topMargin=dp(2); bottomMargin=dp(2)
            if (mine) marginStart = resources.displayMetrics.widthPixels - maxW else marginEnd = resources.displayMetrics.widthPixels - maxW
        })
        chatBox.addView(wrap, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
    }

    private fun textLine(t: String) = TextView(this).apply { text = t; textSize = 15f; setTextColor(TXT); setLineSpacing(0f, 1.2f) }
    private fun scrollBottom() { handler.post { chatScroll.fullScroll(View.FOCUS_DOWN) } }

    private fun updateStatus() {
        val mesh = if (MeshBridge.running) " · 📡 ${MeshBridge.peersConnected}" else ""
        statusTv.text = if (WsClient.connected) "Online$mesh" else "Offline$mesh"
    }

    // ── Send ──
    private fun sendMsg() {
        val text = input.text.toString().trim(); if (text.isEmpty()) return
        sendContent(text, "text")
        input.setText("")
    }

    private fun sendContent(body: String, msgType: String) {
        val msgId = ByteArray(6).also { SecureRandom().nextBytes(it) }.joinToString("") { "%02X".format(it) }
        val t = System.currentTimeMillis()
        val viaNet = if (isGroup) WsClient.sendGroupMsg(peerId, msgId, body, msgType) else WsClient.send(peerId, msgId, body, msgType)
        val viaMesh = if (!isGroup) MeshBridge.sendDirect(peerId, msgId, body) else false
        if (!viaNet && !viaMesh && msgType != "image" && msgType != "voice") { toast("Na internet hai na mesh. Bluetooth + Location on karein."); return }
        val status = if (viaNet) "sent" else "mesh"
        val preview = when (msgType) { "image" -> "📷 Photo"; "voice" -> "🎤 Voice note"; else -> body }
        addBubble(body, true, fmtTime(t), status, msgType); scrollBottom()
        Thread {
            db.saveMessage(msgId, peerId, Session.id, body, t, true, status, msgType)
            db.upsertConversation(peerId, peerName, preview, t, false, isGroup)
        }.start()
    }

    // ── Image picker ──
    private fun pickImage() {
        startActivityForResult(Intent(Intent.ACTION_PICK).apply { type = "image/*" }, PICK_IMAGE)
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == PICK_IMAGE && resultCode == RESULT_OK) {
            val uri = data?.data ?: return
            toast("Photo compress ho rahi hai...")
            Thread {
                val b64 = MediaHelper.imageToBase64(this, uri)
                if (b64 != null) handler.post { sendContent(b64, "image") }
                else handler.post { toast("Photo load nahi ho saki") }
            }.start()
        }
    }

    // ── Voice note ──
    private fun startVoiceRecord() {
        if (!hasMicPermission()) return
        toast("Recording... (chhodein to bhejna)")
        MediaHelper.startRecording(this)
    }

    private fun stopVoiceRecord(send: Boolean) {
        if (send) {
            Thread {
                val result = MediaHelper.stopRecording()
                if (result != null) handler.post { sendContent(result.first, "voice") }
                else handler.post { toast("Recording fail ho gai") }
            }.start()
        } else MediaHelper.cancelRecording()
    }

    private fun hasMicPermission() = ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED
    private fun checkAudioPermission(then: () -> Unit) {
        if (hasMicPermission()) then()
        else ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.RECORD_AUDIO), 98)
    }

    // ── Call ──
    private fun startVideoCall() {
        if (!WsClient.connected) { toast("Video call ke liye internet chahiye"); return }
        val id = java.util.UUID.randomUUID().toString().replace("-","").uppercase().take(12)
        startActivity(android.content.Intent(this, VideoCallActivity::class.java)
            .putExtra(VideoCallActivity.PEER_ID, peerId)
            .putExtra(VideoCallActivity.PEER_NAME, peerName)
            .putExtra(VideoCallActivity.IS_CALLER, true)
            .putExtra(VideoCallActivity.CALL_ID, id))
    }

    private fun startCall(initiate: Boolean) {
        if (inCall) return
        if (!hasMicPermission()) { pendingInitiate = initiate; checkAudioPermission {}; return }
        if (!WsClient.connected) { toast("Call ke liye internet chahiye"); return }
        inCall = true; callOverlay.visibility = View.VISIBLE; callStatusTv.text = if (initiate) "Ring ho rahi hai..." else "Connecting..."
        netCall = InternetVoiceCall(peerId) { msg -> handler.post { callStatusTv.text = msg } }
        netCall?.start(initiate)
    }

    private fun endCall(sendEnd: Boolean = true) {
        if (!inCall) return; inCall = false; netCall?.stop(sendEnd); netCall = null
        handler.post { callOverlay.visibility = View.GONE }
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, results: IntArray) {
        val granted = results.isNotEmpty() && results[0] == PackageManager.PERMISSION_GRANTED
        when (requestCode) {
            99 -> if (granted) startCall(pendingInitiate) else toast("Mic permission chahiye call ke liye")
            98 -> if (granted) toast("Ab mic button hold karein") else toast("Mic permission deny ki")
        }
    }

    // ── RabtaEvents ──
    override fun onConnected()    { handler.post { updateStatus() } }
    override fun onDisconnected() { handler.post { updateStatus() } }
    override fun onMessage(fromId: String, fromName: String, msgId: String, body: String, t: Long, msgType: String, groupId: String) {
        val match = if (isGroup) groupId == peerId else fromId == peerId
        if (!match) return
        val sender = if (isGroup && fromId != Session.id) fromName else ""
        handler.post { addBubble(body, false, fmtTime(t), "received", msgType, sender); scrollBottom() }
        // send read receipt
        if (!isGroup) WsClient.sendRead(fromId, msgId)
    }
    override fun onAck(msgId: String, status: String) { Thread { db.updateStatus(msgId, status) }.start() }
    override fun onRead(msgId: String, byId: String) {
        if (byId == peerId) Thread { db.markAllRead(peerId) }.start()
    }
    override fun onTyping(fromId: String) {
        if (fromId != peerId || isGroup) return
        handler.post {
            typingTv.visibility = View.VISIBLE; statusTv.visibility = View.GONE
            handler.removeCallbacks(typingHideRunnable)
            typingHideRunnable = Runnable { typingTv.visibility = View.GONE; statusTv.visibility = View.VISIBLE }
            handler.postDelayed(typingHideRunnable, 3000)
        }
    }
    override fun onCallAudio(fromId: String, data: String) { if (fromId == peerId) netCall?.onAudio(data) }
    override fun onVideoOffer(fromId: String, fromName: String, callId: String, sdp: String) {
        if (fromId != peerId) return
        handler.post {
            startActivity(android.content.Intent(this, VideoCallActivity::class.java)
                .putExtra(VideoCallActivity.PEER_ID, fromId)
                .putExtra(VideoCallActivity.PEER_NAME, fromName)
                .putExtra(VideoCallActivity.IS_CALLER, false)
                .putExtra(VideoCallActivity.CALL_ID, callId)
                .putExtra(VideoCallActivity.OFFER_SDP, sdp))
        }
    }
    override fun onCallEnd(fromId: String) { if (fromId == peerId) handler.post { endCall(false); toast("Call khatam") } }
}
