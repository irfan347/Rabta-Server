package com.irfan.rabta

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import org.json.JSONObject
import java.security.SecureRandom
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class ChatActivity : Activity(), WsClient.Listener {

    private val G = 0xFF25D366.toInt()
    private val BG = 0xFF0B141A.toInt()
    private val CARD = 0xFF1F2C34.toInt()
    private val SUB = 0xFF8696A0.toInt()
    private val TXT = 0xFFE9EDEF.toInt()
    private val SENT = 0xFF005C4B.toInt()
    private val RECV = 0xFF1F2C34.toInt()

    private lateinit var peerId: String
    private lateinit var peerName: String
    private lateinit var chatBox: LinearLayout
    private lateinit var chatScroll: ScrollView
    private lateinit var input: EditText
    private lateinit var statusTv: TextView
    private val handler = Handler(Looper.getMainLooper())
    private lateinit var db: Db

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Session.init(this)
        peerId = intent.getStringExtra("peerId") ?: ""; peerName = intent.getStringExtra("peerName") ?: "User"
        if (peerId.isEmpty()) { finish(); return }
        db = Db.get(this)
        buildUi()
        WsClient.setListener(this)
        loadHistory()
    }
    override fun onResume() { super.onResume(); WsClient.setListener(this); updateStatus() }
    override fun onDestroy() { WsClient.setListener(null); Thread { db.clearUnread(peerId) }.start(); super.onDestroy() }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun round(c: Int, r: Int) = GradientDrawable().apply { setColor(c); cornerRadius = dp(r).toFloat() }
    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()
    private fun fmtTime(t: Long) = SimpleDateFormat("HH:mm", Locale.getDefault()).format(Date(t))
    private fun colors() = listOf(0xFF2196F3, 0xFF9C27B0, 0xFFE91E63, 0xFF009688)
    private fun avatar(name: String, size: Int) = TextView(this).apply {
        text = name.filter { it.isLetterOrDigit() }.take(1).uppercase().ifEmpty { "?" }
        textSize = (size * 0.38f); typeface = Typeface.DEFAULT_BOLD; setTextColor(Color.WHITE); gravity = Gravity.CENTER
        background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(colors()[(name.hashCode() and 0x7FFFFFFF) % colors().size].toInt()) }
    }

    private fun buildUi() {
        window.statusBarColor = CARD
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(BG) }
        setContentView(root)

        // Header
        val header = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setBackgroundColor(CARD); setPadding(dp(8), dp(10), dp(16), dp(10)) }
        val back = TextView(this).apply { text = "←"; textSize = 22f; setTextColor(TXT); setPadding(dp(8), dp(4), dp(16), dp(4)); isClickable = true; setOnClickListener { finish() } }
        header.addView(back)
        header.addView(avatar(peerName, dp(42)), LinearLayout.LayoutParams(dp(42), dp(42)))
        val hCol = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(12), 0, 0, 0) }
        TextView(this).also { tv -> tv.text = peerName; tv.textSize = 17f; tv.setTextColor(TXT); tv.typeface = Typeface.DEFAULT_BOLD; hCol.addView(tv) }
        statusTv = TextView(this).apply { textSize = 13f; setTextColor(SUB) }
        hCol.addView(statusTv)
        header.addView(hCol, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        root.addView(header)

        // Messages
        chatScroll = ScrollView(this).apply { setBackgroundColor(BG) }
        chatBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(8), dp(8), dp(8), dp(8)) }
        chatScroll.addView(chatBox)
        root.addView(chatScroll, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))

        // Input bar
        val bar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.BOTTOM
            setBackgroundColor(CARD); setPadding(dp(8), dp(8), dp(8), dp(8))
        }
        input = EditText(this).apply {
            hint = "Message"; textSize = 16f; setTextColor(TXT); setHintTextColor(SUB); maxLines = 5
            background = round(0xFF2A3942.toInt(), 24); setPadding(dp(16), dp(10), dp(16), dp(10))
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE or InputType.TYPE_TEXT_FLAG_CAP_SENTENCES
        }
        bar.addView(input, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply { marginEnd = dp(8) })
        val send = TextView(this).apply {
            text = "↑"; textSize = 22f; setTextColor(Color.WHITE); gravity = Gravity.CENTER
            background = round(G, 24); setPadding(0, 0, 0, 0); isClickable = true; setOnClickListener { sendMsg() }
        }
        bar.addView(send, LinearLayout.LayoutParams(dp(48), dp(48)))
        root.addView(bar)
    }

    private fun loadHistory() {
        Thread {
            val msgs = db.messages(peerId)
            db.clearUnread(peerId)
            handler.post {
                chatBox.removeAllViews()
                msgs.forEach { m -> addBubble(m.body, m.mine, fmtTime(m.sentAt), m.status) }
                scrollToBottom()
            }
        }.start()
    }

    private fun addBubble(text: String, mine: Boolean, time: String, status: String = "sent") {
        val wrap = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = if (mine) Gravity.END else Gravity.START }
        val bubble = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = round(if (mine) SENT else RECV, 12)
            setPadding(dp(12), dp(8), dp(12), dp(8))
        }
        TextView(this).also { tv -> tv.text = text; tv.textSize = 15f; tv.setTextColor(TXT); tv.setLineSpacing(0f, 1.2f); bubble.addView(tv) }
        val foot = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.END or Gravity.BOTTOM; setPadding(dp(8), dp(2), 0, 0) }
        foot.addView(TextView(this).apply { this.text = time; textSize = 11f; setTextColor(SUB) })
        if (mine) foot.addView(TextView(this).apply {
            this.text = when (status) { "delivered" -> " ✓✓"; "read" -> " ✓✓"; else -> " ✓" }
            textSize = 11f; setTextColor(if (status == "read") G else SUB)
        })
        bubble.addView(foot)
        val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
            topMargin = dp(2); bottomMargin = dp(2)
            if (mine) { marginStart = dp(60) } else { marginEnd = dp(60) }
        }
        wrap.addView(bubble, lp)
        chatBox.addView(wrap, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
    }

    private fun scrollToBottom() { handler.post { chatScroll.fullScroll(View.FOCUS_DOWN) } }

    private fun sendMsg() {
        val text = input.text.toString().trim(); if (text.isEmpty()) return
        val msgId = ByteArray(8).also { SecureRandom().nextBytes(it) }.joinToString("") { "%02X".format(it) }
        val t = System.currentTimeMillis()
        input.setText("")

        val sentViaInternet = WsClient.send(peerId, msgId, text)
        val status = if (sentViaInternet) "sent" else "mesh"

        addBubble(text, true, fmtTime(t), "sent"); scrollToBottom()
        Thread { db.saveMessage(msgId, peerId, Session.id, text, t, true, status); db.upsertConversation(peerId, peerName, text, t, false) }.start()

        if (!sentViaInternet) {
            // try mesh
            MeshBridge.sendText(peerId, peerName, msgId, text)
            if (!WsClient.connected) toast("Offline - mesh se bhejna chal raha hai")
        }
    }

    private fun updateStatus() { statusTv.text = if (WsClient.connected) "Online" else "Offline (mesh chal raha hai)" }

    // WsClient.Listener
    override fun onWsConnected() { handler.post { updateStatus() } }
    override fun onWsDisconnected() { handler.post { updateStatus() } }
    override fun onWsMessage(fromId: String, fromName: String, msgId: String, body: String, t: Long) {
        if (fromId != peerId) return
        Thread { db.saveMessage(msgId, peerId, fromId, body, t, false, "delivered") }.start()
        handler.post { addBubble(body, false, fmtTime(t)); scrollToBottom() }
    }
    override fun onWsAck(msgId: String, status: String) {
        Thread { db.updateStatus(msgId, status) }.start()
    }
}
