package com.irfan.rabta

object MeshBridge {
    private var router: Router? = null

    fun attach(r: Router) { router = r }
    fun detach() { router = null }

    fun sendText(toId: String, toName: String, msgId: String, body: String) {
        router?.sendText("DM:$toId:$msgId:$body")
    }

    fun startCall(call: VoiceCall) {
        call.start()
    }

    fun endCall() { }
}
