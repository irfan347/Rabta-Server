package com.irfan.rabta

import org.json.JSONObject
import java.security.SecureRandom

/**
 * Bridge between ChatActivity and the Router (mesh).
 * The Router lives in ConversationListActivity; the bridge
 * lets ChatActivity send via mesh without holding a reference.
 */
object MeshBridge {
    private var router: Router? = null

    fun attach(r: Router) { router = r }
    fun detach() { router = null }

    /** Send a 1-on-1 message via mesh (Router broadcasts to all connected peers). */
    fun sendText(toId: String, toName: String, msgId: String, body: String) {
        router?.sendText("DM:$toId:$msgId:$body") // encoded so receiver knows it's a DM
    }
}
