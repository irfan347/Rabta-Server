package com.irfan.rabta

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.os.IBinder

/** Background service: keeps WebSocket alive and shows notifications. */
class MessageService : Service(), RabtaEvents.Listener {

    companion object {
        const val MSG_CHANNEL  = "rabta_messages"
        const val CALL_CHANNEL = "rabta_calls"
        const val CALL_NOTIF   = 2
        private var msgId      = 100

        fun start(ctx: Context) {
            try { ctx.startForegroundService(Intent(ctx, MessageService::class.java)) } catch (_: Exception) {}
        }
        fun stop(ctx: Context) {
            try { ctx.stopService(Intent(ctx, MessageService::class.java)) } catch (_: Exception) {}
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        createChannels()
        startForeground(1, persistentNotification())
        RabtaEvents.add(this)
        if (Session.loggedIn) WsClient.connect(Session)
    }

    override fun onDestroy() { RabtaEvents.remove(this); super.onDestroy() }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (Session.loggedIn && !WsClient.connected) WsClient.connect(Session)
        return START_STICKY
    }

    // --- RabtaEvents.Listener ---
    override fun onMessage(fromId: String, fromName: String, msgId: String, body: String, t: Long) {
        // Save to DB
        Thread { try {
            Db.get(this).saveMessage(msgId, fromId, fromId, body, t, false)
            Db.get(this).upsertConversation(fromId, fromName, body, t, true)
        } catch (_: Exception) {} }.start()
        showMessageNotification(fromId, fromName, body)
    }

    override fun onIncomingCall(fromId: String, fromName: String) {
        showCallNotification(fromId, fromName)
    }

    override fun onCallEnd(fromId: String) {
        (getSystemService(NOTIFICATION_SERVICE) as NotificationManager).cancel(CALL_NOTIF)
    }

    // --- Notifications ---
    private fun showMessageNotification(fromId: String, fromName: String, body: String) {
        val chatIntent = Intent(this, ChatActivity::class.java)
            .putExtra("peerId", fromId).putExtra("peerName", fromName)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
        val pi = PendingIntent.getActivity(this, fromId.hashCode(), chatIntent, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
        val n = Notification.Builder(this, MSG_CHANNEL)
            .setSmallIcon(android.R.drawable.ic_dialog_email)
            .setContentTitle(fromName)
            .setContentText(body)
            .setAutoCancel(true)
            .setContentIntent(pi)
            .setWhen(System.currentTimeMillis())
            .setShowWhen(true)
            .build()
        (getSystemService(NOTIFICATION_SERVICE) as NotificationManager).notify(msgId++, n)
    }

    private fun showCallNotification(fromId: String, fromName: String) {
        val callIntent = Intent(this, IncomingCallActivity::class.java)
            .putExtra("fromId", fromId).putExtra("fromName", fromName)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
        val pi = PendingIntent.getActivity(this, 0, callIntent, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
        val n = Notification.Builder(this, CALL_CHANNEL)
            .setSmallIcon(android.R.drawable.ic_menu_call)
            .setContentTitle("Incoming Call")
            .setContentText("$fromName is calling...")
            .setCategory(Notification.CATEGORY_CALL)
            .setFullScreenIntent(pi, true)
            .setAutoCancel(false)
            .setOngoing(true)
            .build()
        (getSystemService(NOTIFICATION_SERVICE) as NotificationManager).notify(CALL_NOTIF, n)
        // Also launch the full-screen activity directly
        try { startActivity(callIntent) } catch (_: Exception) {}
    }

    private fun persistentNotification(): Notification {
        val pi = PendingIntent.getActivity(this, 0, Intent(this, ConversationListActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
        return Notification.Builder(this, MSG_CHANNEL)
            .setSmallIcon(android.R.drawable.ic_dialog_email)
            .setContentTitle("Rabta")
            .setContentText("Messages ki waiting mein...")
            .setContentIntent(pi)
            .setOngoing(true)
            .build()
    }

    private fun createChannels() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel(MSG_CHANNEL, "Messages", NotificationManager.IMPORTANCE_HIGH).apply {
            description = "New message notifications"; enableLights(true); enableVibration(true)
        })
        nm.createNotificationChannel(NotificationChannel(CALL_CHANNEL, "Calls", NotificationManager.IMPORTANCE_MAX).apply {
            description = "Incoming call notifications"
        })
    }
}
