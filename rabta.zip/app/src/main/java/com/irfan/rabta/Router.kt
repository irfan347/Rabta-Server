package com.irfan.rabta

import android.content.Context
import com.google.android.gms.nearby.connection.Payload
import org.json.JSONObject
import java.security.SecureRandom

/**
 * The mesh brain. Sits on top of Mesh (transport) and adds what other offline
 * chat apps don't do well:
 *
 *  - Multi-hop: a message you send is re-broadcast by every phone that receives it,
 *    so it travels far beyond your own Bluetooth range (hop by hop).
 *  - Carry-delivery: messages are held in memory and handed to NEW phones the moment
 *    they connect - so a message reaches someone who wasn't even nearby when it was sent.
 *    People walking around physically carry messages to each other.
 *  - De-duplication: every message has an id; a phone processes each id once, so
 *    messages don't loop forever in the mesh.
 *
 * Envelope (compact JSON):
 *   i = id, f = from userId, n = from name, h = hops left, s = sent time(ms), b = body
 *   (v1: all chat is broadcast to the local mesh; direct 1-to-1 addressing comes next)
 */
class Router(private val ctx: Context, private val ui: UiListener) : Mesh.Listener, LongRange.Listener {

    interface UiListener {
        fun onPeople()
        fun onMessage(fromName: String, body: String, hops: Int, mine: Boolean)
        fun onFileStart(name: String, size: Long)
        fun onFileDone()
        fun onStream(payload: Payload)
        fun onAudio(frame: ByteArray)
        fun onStatus(msg: String)
    }

    companion object {
        private const val START_HOPS = 8          // how far a message can travel
        private const val MAX_STORE = 500         // carry-delivery buffer size
        private const val MAX_SEEN = 3000
        private const val EXPIRY_MS = 24 * 3600 * 1000L
    }

    private val mesh = Mesh(ctx, this)
    private val prefs = ctx.getSharedPreferences("rabta", Context.MODE_PRIVATE)
    val myId: String = prefs.getString("userId", null) ?: run {
        val id = ByteArray(5).also { SecureRandom().nextBytes(it) }.joinToString("") { "%02X".format(it) }
        prefs.edit().putString("userId", id).apply(); id
    }
    private var myName = "My phone"

    private val seen = object : LinkedHashMap<String, Boolean>(16, 0.75f, false) {
        override fun removeEldestEntry(e: Map.Entry<String, Boolean>?) = size > MAX_SEEN
    }
    private val store = LinkedHashMap<String, String>()  // id -> envelope json (for carry-delivery)
    val found = LinkedHashMap<String, String>()          // discovered, not-yet-connected endpoints
    // Long Range (Bluetooth Coded PHY) second radio path
    private var lr: LongRange? = null
    var longRangeOn = false
        private set
    val lrPeers = LinkedHashMap<String, Triple<String, Int, Long>>() // userId -> (name, rssi, lastSeen)
    val connectedUserIds: Collection<String> get() = mesh.userIdOf.values

    val connected get() = mesh.connected

    fun start(name: String) {
        myName = name.ifBlank { "My phone" }
        mesh.start(myName, myId)
        lr = LongRange(ctx, this)
        longRangeOn = lr?.start(myId, myName) == true
        if (!longRangeOn) lr = null
    }
    fun stop() {
        mesh.stop()
        lr?.stop(); lr = null; longRangeOn = false; lrPeers.clear()
    }
    /** Letters (bytes) a message can have to also go over Long Range. */
    fun longRangeLimit(): Int = lr?.maxBodyBytes(myName) ?: 0
    fun connect(endpointId: String) = mesh.connect(endpointId)
    fun sendFile(uri: android.net.Uri, name: String, size: Long) = mesh.sendFile(uri, name, size)
    fun sendStream(p: Payload) = mesh.sendStream(p)
    fun sendAudio(frame: ByteArray) = mesh.sendAudio(frame)

    // ---------- send a chat message into the mesh ----------
    fun sendText(body: String) {
        val id = ByteArray(6).also { SecureRandom().nextBytes(it) }.joinToString("") { "%02X".format(it) }
        val env = JSONObject()
            .put("i", id).put("f", myId).put("n", myName)
            .put("h", START_HOPS).put("s", System.currentTimeMillis()).put("b", body)
            .toString()
        seen[id] = true
        remember(id, env)
        mesh.sendEnvelopeToAll(env)
        if (longRangeOn && lr?.broadcast(id, myId, myName, START_HOPS, body) != true) {
            ui.onStatus("Message Long Range ke liye lamba tha - sirf qareeb walon ko gaya")
        }
    }

    // ---------- receive from the transport ----------
    override fun onEnvelope(endpointId: String, json: String) {
        val o = try { JSONObject(json) } catch (_: Exception) { return }
        handleIncoming(o, endpointId)
    }

    /** Shared by both radio paths: deliver once, then forward on both. */
    private fun handleIncoming(o: JSONObject, sourceEndpoint: String?) {
        val json = o.toString()
        val id = o.optString("i"); if (id.isEmpty() || seen.containsKey(id)) return
        seen[id] = true

        val from = o.optString("f")
        if (from == myId) return                       // my own message echoed back
        val hopsLeft = o.optInt("h", 0)
        val body = o.optString("b")
        val name = o.optString("n", "Someone")
        val sentHops = START_HOPS - hopsLeft + 1

        ui.onMessage(name, body, sentHops, mine = false)   // deliver to the user

        // forward onward (one less hop), and keep a copy to carry to future peers
        if (hopsLeft > 1) {
            val fwd = JSONObject(json).put("h", hopsLeft - 1).toString()
            remember(id, fwd)
            mesh.sendEnvelopeToAll(fwd, exceptEndpoint = sourceEndpoint)
            if (longRangeOn) lr?.broadcast(id, from, name, hopsLeft - 1, body)
        } else {
            remember(id, json)
        }
    }

    // when a new phone connects, hand it everything we're carrying (carry-delivery)
    override fun onConnected(endpointId: String, userId: String, name: String) {
        found.remove(endpointId)
        ui.onStatus("Connected to $name")
        ui.onPeople()
        val now = System.currentTimeMillis()
        synchronized(store) {
            val it = store.entries.iterator()
            while (it.hasNext()) {
                val e = it.next()
                val ts = try { JSONObject(e.value).optLong("s") } catch (_: Exception) { 0L }
                if (now - ts > EXPIRY_MS) { it.remove(); continue }
                mesh.sendEnvelopeTo(endpointId, e.value)
            }
        }
    }

    private fun remember(id: String, env: String) {
        synchronized(store) {
            store[id] = env
            while (store.size > MAX_STORE) store.remove(store.keys.first())
        }
    }

    // ---------- pass-throughs ----------
    override fun onFound(endpointId: String, name: String) { found[endpointId] = name; ui.onPeople() }
    override fun onLost(endpointId: String) { found.remove(endpointId); ui.onPeople() }
    override fun onConnecting(endpointId: String, name: String) = ui.onStatus("Connecting to $name…")
    override fun onDisconnected(endpointId: String) { ui.onStatus("Someone disconnected"); ui.onPeople() }
    override fun onFileStart(endpointId: String, payloadId: Long, name: String, size: Long) = ui.onFileStart(name, size)
    override fun onFileDone(endpointId: String, payloadId: Long) = ui.onFileDone()
    override fun onStream(endpointId: String, payload: Payload) = ui.onStream(payload)
    override fun onAudio(endpointId: String, frame: ByteArray) = ui.onAudio(frame)
    override fun onStatus(msg: String) = ui.onStatus(msg)

    // ---------- Long Range ----------
    override fun onLrMessage(id: String, from: String, name: String, hopsLeft: Int, body: String) {
        val o = JSONObject().put("i", id).put("f", from).put("n", name)
            .put("h", hopsLeft).put("s", System.currentTimeMillis()).put("b", body)
        handleIncoming(o, null)
    }
    override fun onLrHello(userId: String, name: String, rssi: Int) {
        if (userId == myId) return
        val isNew = !lrPeers.containsKey(userId)
        lrPeers[userId] = Triple(name, rssi, System.currentTimeMillis())
        if (isNew) ui.onPeople()
    }
    override fun onLrStatus(msg: String) = ui.onStatus(msg)

}
