package com.irfan.rabta

import android.content.Context

/** Logged-in user state, persisted in SharedPreferences. */
object Session {
    private const val P = "rabta_session"
    private lateinit var ctx: Context

    fun init(c: Context) { ctx = c.applicationContext }

    var id: String get() = prefs().getString("id", "") ?: ""; set(v) { prefs().edit().putString("id", v).apply() }
    var username: String get() = prefs().getString("username", "") ?: ""; set(v) { prefs().edit().putString("username", v).apply() }
    var name: String get() = prefs().getString("name", "") ?: ""; set(v) { prefs().edit().putString("name", v).apply() }
    var token: String get() = prefs().getString("token", "") ?: ""; set(v) { prefs().edit().putString("token", v).apply() }
    var serverUrl: String get() = prefs().getString("server", "") ?: ""; set(v) { prefs().edit().putString("server", v.trim().trimEnd('/')).apply() }

    val loggedIn get() = id.isNotEmpty() && token.isNotEmpty() && serverUrl.isNotEmpty()

    fun logout() { prefs().edit().clear().apply() }
    private fun prefs() = ctx.getSharedPreferences(P, Context.MODE_PRIVATE)
}
